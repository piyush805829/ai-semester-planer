# AI Semester Planner — Implementation Plan

## Approved Design Decisions

| ID | Decision | Approved Choice |
|---|---|---|
| D-01 | AI API | OpenAI GPT-3.5-turbo |
| D-02 | Task editing | Delete and re-add only |
| D-03 | Status transition | Any status can be set freely |
| D-04 | Upcoming window | Fixed at 7 days |
| D-05 | Study week | Monday–Friday only |
| D-06 | Semesters | One active semester at a time |
| D-07 | Due date rule | Must be today or a future date within semester range |
| D-08 | Data file | data/planner_data.json inside project folder |
| D-09 | Subject editing | Delete and re-add only |
| D-10 | Progress chart | Plotly pie chart |

---

## Top-Level Overview

Build a single-user, local Streamlit application that lets a student manage one semester of study.
The app stores one semester, its subjects, and its tasks in a JSON file. It generates a weekly study
schedule using either an OpenAI GPT-3.5-turbo suggestion or a rule-based fallback. A sidebar
navigates between six pages: Semester Setup, Subjects, Tasks, Deadlines, Study Plan, and Progress
Dashboard. All business logic lives in the models and services layers; app.py is pure UI.

---

## Folder Structure

```
ai_semester_planner/
├── app.py
├── models/
│   ├── __init__.py
│   ├── semester.py
│   ├── subject.py
│   ├── task.py
│   └── planner.py
├── services/
│   ├── __init__.py
│   ├── ai_service.py
│   ├── rule_planner.py
│   └── data_store.py
├── utils/
│   ├── __init__.py
│   ├── validators.py
│   └── exceptions.py
├── data/
│   └── .gitkeep
├── tests/
│   ├── test_semester.py
│   ├── test_subject.py
│   ├── test_task.py
│   ├── test_planner.py
│   ├── test_rule_planner.py
│   └── test_validators.py
├── requirements.txt
└── README.md
```

---

## Sub-Tasks

---

### Sub-Task 1 — Project Scaffolding and Custom Exceptions

**Status:** [ ] pending

**Intent:**
Create the full folder structure, empty __init__.py files, requirements.txt, README.md, and
all custom exception classes. This gives every later sub-task a stable foundation to import from
and avoids circular-dependency surprises.

**Expected Outcomes:**
- All folders and __init__.py files exist.
- requirements.txt lists: streamlit, openai, plotly, pytest.
- utils/exceptions.py defines all 9 custom exception classes.
- Running `pytest tests/` with no test files produces zero errors.

**Todo List:**
1. Create the folder tree: models/, services/, utils/, data/, tests/.
2. Add __init__.py to models/, services/, utils/, tests/.
3. Create data/.gitkeep so the folder is tracked by git.
4. Write utils/exceptions.py with: PlannerError, InvalidDateRangeError,
   DuplicateCourseCodeError, SubjectNotFoundError, InvalidCreditsError,
   EmptyFieldError, InvalidStudyHoursError, AIServiceError, DataStoreError.
   Each exception takes an optional string message. All inherit from PlannerError.
   PlannerError inherits from Exception.
5. Write requirements.txt: streamlit, openai, plotly, pytest.
6. Write a minimal README.md: project title, setup instructions (pip install, streamlit run).

**Relevant Context:**
- utils/exceptions.py is imported by every other module — it must have zero imports of its own.
- No test file is needed for exceptions; they are exercised by validator tests in Sub-Task 3.

---

### Sub-Task 2 — Data Models

**Status:** [ ] pending

**Intent:**
Implement the three core data classes (Semester, Subject, Task) and the three enums
(TaskType, Priority, TaskStatus). These are plain Python classes with no external dependencies
other than the standard library and the custom exceptions from Sub-Task 1.

**Expected Outcomes:**
- models/semester.py: Semester class with contains_date, days_remaining, to_dict, from_dict.
- models/subject.py: Subject class with to_dict, from_dict.
- models/task.py: TaskType, Priority, TaskStatus enums; Task class with is_overdue,
  days_until_due, advance_status, to_dict, from_dict.
- All three test files (test_semester.py, test_subject.py, test_task.py) pass with pytest.

**Todo List:**
1. Write models/task.py:
   - TaskType enum: EXAM, ASSIGNMENT, PROJECT, OTHER.
   - Priority enum: LOW, MEDIUM, HIGH (assign integer values 1, 2, 3 for sort ordering).
   - TaskStatus enum: PENDING, IN_PROGRESS, COMPLETED.
   - Task dataclass or regular class with fields: title (str), subject_code (str),
     due_date (date), task_type (TaskType), priority (Priority), status (TaskStatus).
   - Default status = TaskStatus.PENDING.
   - is_overdue(): returns True if due_date < date.today() and status != COMPLETED.
   - days_until_due(): returns (due_date - date.today()).days (negative = overdue).
   - advance_status(): not used with D-03 free-set, but keep as a convenience no-op or remove.
     NOTE: D-03 says any status can be set freely, so advance_status is not needed.
     Omit it. Status is set directly by the UI.
   - to_dict(): returns a plain dict with all fields serialised to strings/ints.
   - from_dict(d) classmethod: reconstructs a Task from a plain dict.

2. Write models/semester.py:
   - Semester class with fields: name (str), start_date (date), end_date (date).
   - contains_date(d): returns True if start_date <= d <= end_date.
   - days_remaining(): returns (end_date - date.today()).days.
   - to_dict() and from_dict(d) classmethod.

3. Write models/subject.py:
   - Subject class with fields: name (str), course_code (str), credits (int).
   - to_dict() and from_dict(d) classmethod.

4. Write tests/test_semester.py:
   - test_contains_date_within_range
   - test_contains_date_outside_range
   - test_days_remaining_future
   - test_semester_serialization_roundtrip

5. Write tests/test_subject.py:
   - test_subject_fields_stored_correctly
   - test_subject_serialization_roundtrip

6. Write tests/test_task.py:
   - test_task_is_overdue_when_past_due_and_not_completed
   - test_task_not_overdue_when_completed
   - test_task_not_overdue_when_future_due
   - test_days_until_due_positive_for_future
   - test_days_until_due_negative_for_past
   - test_task_serialization_roundtrip

**Relevant Context:**
- Use Python's dataclasses module to keep boilerplate low (beginner-friendly).
- dates are stored as ISO strings ("YYYY-MM-DD") in JSON; from_dict must parse them with
  date.fromisoformat().
- Priority integer values (LOW=1, MEDIUM=2, HIGH=3) enable simple sort() calls.
- D-03: status is set freely by the UI. Task itself does not enforce transitions.

---

### Sub-Task 3 — Validators

**Status:** [ ] pending

**Intent:**
Implement the Validator class in utils/validators.py. Centralised validation keeps all rules
in one place and decouples them from both the models and the UI. Every rule from the design
document is encoded here and tested exhaustively.

**Expected Outcomes:**
- utils/validators.py: Validator class with 4 static methods.
- tests/test_validators.py passes all cases including happy-path and every error path.

**Todo List:**
1. Write utils/validators.py with a Validator class containing only static methods:

   validate_semester(name, start_date, end_date):
     - Raise EmptyFieldError if name is blank after strip().
     - Raise EmptyFieldError if name > 50 characters.
     - Raise InvalidDateRangeError if end_date <= start_date + 6 days
       (end must be at least 7 days after start).

   validate_subject(name, course_code, credits, existing_codes):
     - Raise EmptyFieldError if name is blank or > 100 chars.
     - Raise EmptyFieldError if course_code is blank or > 10 chars.
     - Raise EmptyFieldError if course_code contains characters other than
       alphanumerics and hyphens (use re.match).
     - Raise DuplicateCourseCodeError if course_code.upper() is in
       {c.upper() for c in existing_codes}.
     - Raise InvalidCreditsError if credits not in range 1–6.

   validate_task(title, subject_code, due_date, semester, existing_codes):
     - Raise EmptyFieldError if title is blank or > 150 chars.
     - Raise SubjectNotFoundError if subject_code.upper() not in
       {c.upper() for c in existing_codes}.
     - Raise InvalidDateRangeError if due_date < date.today()
       (D-07: must be today or future).
     - Raise InvalidDateRangeError if not semester.contains_date(due_date).

   validate_study_hours(hours):
     - Raise InvalidStudyHoursError if hours < 1.0 or hours > 12.0.

2. Write tests/test_validators.py:
   - test_valid_semester_passes
   - test_semester_name_empty_raises
   - test_semester_name_too_long_raises
   - test_semester_end_too_soon_raises
   - test_valid_subject_passes
   - test_duplicate_course_code_raises (case-insensitive)
   - test_invalid_credits_raises (0, 7, negative)
   - test_valid_task_passes
   - test_task_past_due_date_raises
   - test_task_outside_semester_raises
   - test_task_unknown_subject_raises
   - test_invalid_study_hours_raises (0, 13, negative)

**Relevant Context:**
- All 4 methods are static — Validator is never instantiated.
- Import only from utils/exceptions.py and the standard library (re, datetime).
- D-07: due_date < date.today() is invalid; due_date == date.today() is valid.

---

### Sub-Task 4 — SemesterPlanner Controller

**Status:** [ ] pending

**Intent:**
Implement the SemesterPlanner class in models/planner.py. This is the central controller that
owns the semester, subjects, and tasks. The UI only calls methods on this object — it never
manipulates lists directly.

**Expected Outcomes:**
- models/planner.py: SemesterPlanner class with all management and query methods.
- tests/test_planner.py passes all cases.

**Todo List:**
1. Write models/planner.py with SemesterPlanner class:

   Fields:
     - semester: Semester | None (None until set)
     - subjects: list[Subject]
     - tasks: list[Task]

   Methods:
     set_semester(semester): replaces current semester; validates via Validator.
     add_subject(subject): validates via Validator; appends to subjects list.
     remove_subject(course_code): removes matching subject and ALL tasks that reference it.
     get_subject_by_code(code): returns Subject or None (case-insensitive lookup).
     add_task(task): validates via Validator; appends to tasks list.
     remove_task(title): removes first task with matching title (exact match).
     get_upcoming_tasks(days=7): returns tasks where 0 <= days_until_due() <= days,
       sorted by due date ascending.
     get_overdue_tasks(): returns tasks where is_overdue() is True,
       sorted by days_until_due() ascending (most overdue first).
     get_progress(): returns dict:
       { "total": int, "completed": int, "pending": int, "pct": float }
       pct = (completed / total * 100) if total > 0 else 0.0.
     get_all_subjects(): returns copy of subjects list.
     get_all_tasks(): returns copy of tasks list.

2. Write tests/test_planner.py:
   - test_add_subject_success
   - test_add_duplicate_subject_raises
   - test_remove_subject_also_removes_its_tasks (cascade delete)
   - test_add_task_success
   - test_add_task_unknown_subject_raises
   - test_get_upcoming_tasks_returns_correct_window
   - test_get_overdue_tasks_excludes_completed
   - test_get_progress_all_pending
   - test_get_progress_all_completed
   - test_get_progress_mixed
   - test_get_progress_no_tasks_returns_zero_pct

**Relevant Context:**
- SemesterPlanner never imports from services/ or utils/validators.py directly.
  Actually it does call Validator — that is the intended design. Import Validator in planner.py.
- remove_subject cascade: filter self.tasks to exclude tasks where subject_code matches.
- All list returns are copies (return list(self.subjects)) to prevent external mutation.

---

### Sub-Task 5 — Rule-Based Planner

**Status:** [ ] pending

**Intent:**
Implement the RuleBasedPlanner class in services/rule_planner.py. This produces a Mon–Fri
weekly schedule by allocating study hours proportionally by credit weight and ordering subjects
by the urgency of their upcoming tasks.

**Expected Outcomes:**
- services/rule_planner.py: RuleBasedPlanner with generate(), _sort_subjects(), _allocate_hours().
- tests/test_rule_planner.py passes.

**Todo List:**
1. Write services/rule_planner.py:

   RuleBasedPlanner class:

   generate(subjects, tasks, hours_per_day) -> dict:
     - Return early with empty dict if subjects is empty.
     - Call _allocate_hours(subjects, hours_per_day) to get subject -> hours mapping.
     - Call _sort_subjects(subjects, tasks) to get ordered subject list.
     - Build the schedule dict with keys: Monday, Tuesday, Wednesday, Thursday, Friday.
     - Each day value is a list of dicts: {"subject": subject.name, "code": subject.course_code,
       "hours": allocated_hours}.
     - Return the schedule dict.

   _allocate_hours(subjects, hours_per_day) -> dict[str, float]:
     - total_credits = sum of subject.credits across all subjects.
     - For each subject: hours = round((subject.credits / total_credits) * hours_per_day, 1).
     - Return dict mapping course_code -> hours.

   _sort_subjects(subjects, tasks) -> list[Subject]:
     - For each subject, find the minimum days_until_due() among its pending/in-progress tasks.
     - If no tasks exist for a subject, assign a large number (e.g. 9999).
     - Sort subjects by that minimum value ascending (most urgent first).
     - Return the sorted list.

2. Write tests/test_rule_planner.py:
   - test_generate_returns_five_days (Mon–Fri keys present)
   - test_generate_empty_subjects_returns_empty_dict
   - test_allocate_hours_proportional_to_credits
   - test_sort_subjects_most_urgent_first
   - test_generate_schedule_shape (each day has one entry per subject)

**Relevant Context:**
- D-05: Mon–Fri only. The schedule dict must have exactly 5 keys.
- Hours are rounded to 1 decimal place for display friendliness.
- Only PENDING and IN_PROGRESS tasks count for urgency sorting.
  Completed tasks do not influence sort order.

---

### Sub-Task 6 — AI Service

**Status:** [ ] pending

**Intent:**
Implement AIService in services/ai_service.py. It wraps the OpenAI GPT-3.5-turbo API and
raises AIServiceError on any failure. The API key is read from the OPENAI_API_KEY environment
variable. The caller (app.py) catches AIServiceError and falls back to RuleBasedPlanner.

**Expected Outcomes:**
- services/ai_service.py: AIService class with generate_plan() and is_available().
- No real API calls in tests — AIService is mocked.
- Unit test demonstrates that AIServiceError is raised when the API call fails.

**Todo List:**
1. Write services/ai_service.py:

   AIService class:

   __init__(self):
     - Read api_key from os.environ.get("OPENAI_API_KEY", "").
     - Store it on self.

   is_available() -> bool:
     - Return True if self.api_key is not empty string.
     - This is a lightweight check; actual connectivity errors are handled in generate_plan.

   generate_plan(subjects, tasks, hours_per_day) -> str:
     - If not is_available(), raise AIServiceError("No API key configured").
     - Build a prompt string containing:
         * System message: "You are a helpful academic study advisor."
         * Subject list: name and credits for each subject.
         * Pending/in-progress tasks sorted by due date: title, subject, due date, priority.
         * Available hours per day.
         * Instruction: return a concise Mon–Fri weekly study plan in plain text.
     - Call openai.chat.completions.create with model="gpt-3.5-turbo", max_tokens=500.
     - Return the response text string.
     - Wrap the entire API call in try/except Exception; on any exception raise
       AIServiceError(str(e)) so the caller always receives a PlannerError subclass.

2. Write a test in tests/ (can be added to a new file tests/test_ai_service.py):
   - test_generate_plan_raises_ai_service_error_when_api_fails:
     Use unittest.mock.patch to mock openai.chat.completions.create to raise an Exception.
     Assert that generate_plan raises AIServiceError.
   - test_is_available_false_when_no_key:
     Temporarily patch os.environ to remove OPENAI_API_KEY.
     Assert is_available() returns False.

**Relevant Context:**
- D-01: OpenAI GPT-3.5-turbo.
- Only PENDING and IN_PROGRESS tasks are included in the prompt. Completed tasks are irrelevant
  to the study plan.
- The prompt should be concise to keep token usage low on the free/low tier.
- Do not hardcode the API key anywhere.

---

### Sub-Task 7 — Data Store (JSON Persistence)

**Status:** [ ] pending

**Intent:**
Implement DataStore in services/data_store.py. It serialises a SemesterPlanner to a JSON file
and deserialises it back. D-08: file is stored at data/planner_data.json inside the project folder.

**Expected Outcomes:**
- services/data_store.py: DataStore class with save(planner) and load() methods.
- save + load round-trip preserves all fields exactly.
- Corrupted or missing file is handled gracefully.

**Todo List:**
1. Write services/data_store.py:

   FILE_PATH constant: Path("data") / "planner_data.json"

   DataStore class (all methods can be static or regular — static is simpler):

   save(planner: SemesterPlanner) -> None:
     - Build a dict:
         {
           "semester": planner.semester.to_dict() if planner.semester else None,
           "subjects": [s.to_dict() for s in planner.subjects],
           "tasks":    [t.to_dict() for t in planner.tasks]
         }
     - Write to FILE_PATH with json.dump, indent=2.
     - Wrap in try/except OSError; raise DataStoreError on failure.

   load() -> SemesterPlanner | None:
     - If FILE_PATH does not exist, return a fresh SemesterPlanner().
     - Read and json.load the file.
     - If any exception occurs during parsing, raise DataStoreError.
     - Reconstruct: Semester.from_dict, Subject.from_dict, Task.from_dict.
     - Return a SemesterPlanner with semester, subjects, and tasks populated directly
       (bypass validators on load to avoid rejecting past data).
     - "Bypass validators on load" means: set planner.semester, planner.subjects,
       planner.tasks directly rather than calling add_subject / add_task.

2. No separate test file needed for DataStore — it is tested implicitly through a
   save/load round-trip integration check. Add a file tests/test_data_store.py:
   - test_save_and_load_roundtrip: create planner, add semester/subject/task, save,
     load, assert all fields match.
   - test_load_returns_empty_planner_when_no_file: patch FILE_PATH to a non-existent path.
   - test_load_raises_data_store_error_on_corrupt_file: write garbage JSON to a temp file.

**Relevant Context:**
- data/ folder must already exist (created in Sub-Task 1 via .gitkeep).
- On load, bypass validators. This allows loading tasks whose due dates may have become past
  (the semester may have ended — the data is still valid historically).
- Enum fields are stored as their .name string (e.g. "HIGH") and reconstructed with
  Priority[d["priority"]].

---

### Sub-Task 8 — Streamlit UI

**Status:** [ ] pending

**Intent:**
Build app.py, the Streamlit entry point. This file contains zero business logic. It instantiates
SemesterPlanner (loaded from DataStore), renders a sidebar with 6 navigation options, and
delegates all user actions to the planner and service objects.

**Expected Outcomes:**
- app.py renders all 6 pages correctly.
- Every user action (add, delete, status change, generate plan) calls the correct model method.
- Data is saved after every mutation.
- All custom exceptions are caught and shown as st.error() messages — no raw tracebacks.
- AI failure shows st.info() fallback notice.

**Todo List:**
1. Initialise session state at the top of app.py:
   - On first load: planner = DataStore.load(); store in st.session_state["planner"].
   - This persists the planner object across Streamlit reruns.

2. Sidebar navigation:
   - st.sidebar.radio with options:
     "🏠 Semester Setup", "📚 Subjects", "📝 Tasks",
     "📅 Deadlines", "🧠 Study Plan", "📊 Progress Dashboard".

3. Page: Semester Setup
   - st.text_input for semester name.
   - st.date_input for start date and end date.
   - [Save Semester] button: calls Validator.validate_semester then planner.set_semester,
     then DataStore.save(planner). Show st.success or st.error.
   - Below the form, if planner.semester exists, display its details in st.info.

4. Page: Subjects
   - Form with name, course_code, credits (st.number_input) → [Add Subject] button.
   - Calls Validator.validate_subject, then planner.add_subject, then DataStore.save.
   - st.dataframe showing all subjects.
   - For each subject: [Delete] button. On click: warn with st.warning if tasks exist,
     then call planner.remove_subject and DataStore.save on confirm.
     Use st.checkbox or a two-click confirm pattern for safety.

5. Page: Tasks
   - Guard: if no subjects, show st.warning and return early.
   - Guard: if no semester, show st.warning and return early.
   - Form: title, subject dropdown (course codes), due date, task type, priority → [Add Task].
   - Calls Validator.validate_task, then planner.add_task, then DataStore.save.
   - st.dataframe showing all tasks with status column.
   - For each task: st.selectbox to change status freely (D-03).
     On change: update task.status directly, then DataStore.save.
   - [Delete] button per task.

6. Page: Deadlines
   - Two sections: "Upcoming (next 7 days)" and "Overdue".
   - Call planner.get_upcoming_tasks(7) and planner.get_overdue_tasks().
   - Render each list as a styled st.dataframe.
   - Show st.success("No overdue tasks!") if overdue list is empty.

7. Page: Study Plan
   - st.number_input for hours per day (1.0–12.0, step 0.5).
   - [Generate Study Plan] button.
   - On click:
       try: plan_text = AIService().generate_plan(subjects, tasks, hours)
       except AIServiceError: st.info("AI unavailable. Showing rule-based plan.")
                              schedule = RuleBasedPlanner().generate(...)
       else: st.markdown(plan_text) and also show rule-based schedule below.
   - Always render the rule-based weekly schedule as a table regardless of AI availability.

8. Page: Progress Dashboard
   - Call planner.get_progress() and render 4 st.metric widgets.
   - Plotly pie chart (D-10): labels = ["Completed", "Pending/In Progress"],
     values = [completed, pending]. Use st.plotly_chart.
   - Tasks by subject bar chart: group tasks by subject_code, count per subject,
     render with st.bar_chart.

**Relevant Context:**
- No try/except is needed around DataStore.save in the UI — DataStoreError is a PlannerError
  and can be caught with a single except PlannerError as e: st.error(str(e)) block.
- D-02: no edit UI is needed; delete and re-add is the only flow.
- D-09: no subject edit UI.
- D-03: task status selectbox shows all three options freely.
- D-06: only one semester; no semester switching UI.
- The app.py file should be under 300 lines. If it grows beyond that, extract page functions
  into a ui/ subfolder.

---

### Sub-Task 9 — Integration, README, and Final Validation

**Status:** [ ] pending

**Intent:**
Wire everything together, verify all tests pass, write the README with setup and run instructions,
and confirm the application runs end-to-end in Streamlit.

**Expected Outcomes:**
- `pytest tests/` passes with zero failures and zero errors.
- `streamlit run app.py` launches without import errors.
- README.md contains: prerequisites, pip install instructions, OPENAI_API_KEY setup,
  how to run, and a brief feature overview.
- data/.gitkeep exists; data/planner_data.json is listed in .gitignore.

**Todo List:**
1. Run pytest tests/ and fix any remaining test failures.
2. Run streamlit run app.py and manually verify each page renders without errors.
3. Test the AI path by setting a real OPENAI_API_KEY and generating a plan.
4. Test the fallback path by unsetting OPENAI_API_KEY and confirming the rule-based plan appears.
5. Write the final README.md:
   - Prerequisites: Python 3.10+, pip.
   - Installation: git clone, pip install -r requirements.txt.
   - Configuration: export OPENAI_API_KEY=your_key (or set on Windows).
   - Running: streamlit run app.py.
   - Feature walkthrough: brief description of each sidebar page.
6. Add a .gitignore with: __pycache__/, *.pyc, data/planner_data.json, .env.

**Relevant Context:**
- If the OpenAI API key is not set, the app must still work fully via the rule-based planner.
- All tests must be runnable without an API key and without network access.
