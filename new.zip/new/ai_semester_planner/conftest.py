# conftest.py — makes the ai_semester_planner package importable when running
# pytest from the ai_semester_planner/ folder.
import sys
from pathlib import Path

# Insert the parent directory (the workspace root) so that
# "import ai_semester_planner.*" works without pip install.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
