"""SemesterPlanner — the central controller for the AI Semester Planner."""

from __future__ import annotations

from datetime import date
from typing import Optional

from ai_semester_planner.models.semester import Semester
from ai_semester_planner.models.subject import Subject
from ai_semester_planner.models.task import AcademicTask, TaskStatus
from ai_semester_planner.utils.exceptions import SubjectNotFoundError
from ai_semester_planner.utils.validators import Validator


class SemesterPlanner:
    """Central controller that owns the semester, subjects, and tasks.

    The Streamlit UI interacts exclusively through this class.
    It never manipulates the lists directly.
    """

    def __init__(self) -> None:
        self.semester: Optional[Semester] = None
        self.subjects: list[Subject] = []
        self.tasks: list[AcademicTask] = []

    # ------------------------------------------------------------------
    # Semester
    # ------------------------------------------------------------------

    def set_semester(
        self,
        name: str,
        start_date: date,
        end_date: date,
        skip_validation: bool = False,
    ) -> None:
        """Create or replace the current semester.

        Args:
            name: Human-readable semester name.
            start_date: First day of the semester.
            end_date: Last day of the semester.
            skip_validation: When True, bypasses validator (used on JSON load).
        """
        if not skip_validation:
            Validator.validate_semester(name, start_date, end_date)
        self.semester = Semester(
            name=name.strip(),
            start_date=start_date,
            end_date=end_date,
        )

    # ------------------------------------------------------------------
    # Subjects
    # ------------------------------------------------------------------

    def add_subject(
        self,
        name: str,
        course_code: str,
        credits: int,
        skip_validation: bool = False,
    ) -> Subject:
        """Validate and add a new subject.

        Args:
            name: Human-readable subject name.
            course_code: Unique identifier for the subject.
            credits: Credit hours (1–6).
            skip_validation: When True, bypasses validator (used on JSON load).

        Returns:
            The newly created :class:`Subject`.
        """
        existing_codes = self._existing_codes()
        if not skip_validation:
            Validator.validate_subject(name, course_code, credits, existing_codes)
        subject = Subject(
            name=name.strip(),
            course_code=course_code.strip().upper(),
            credits=credits,
        )
        self.subjects.append(subject)
        return subject

    def remove_subject(self, course_code: str) -> None:
        """Remove a subject and all tasks that reference it (cascade delete).

        Args:
            course_code: The course code of the subject to remove.

        Raises:
            SubjectNotFoundError: if no subject with the given code exists.
        """
        code_upper = course_code.upper()
        matching = [s for s in self.subjects if s.course_code.upper() == code_upper]
        if not matching:
            raise SubjectNotFoundError(
                f"No subject with course code '{course_code}' found."
            )
        self.subjects = [
            s for s in self.subjects if s.course_code.upper() != code_upper
        ]
        self.tasks = [
            t for t in self.tasks if t.subject_code.upper() != code_upper
        ]

    def get_subject_by_code(self, course_code: str) -> Optional[Subject]:
        """Return the :class:`Subject` matching *course_code*, or None."""
        code_upper = course_code.upper()
        for subject in self.subjects:
            if subject.course_code.upper() == code_upper:
                return subject
        return None

    def get_all_subjects(self) -> list[Subject]:
        """Return a copy of the subjects list."""
        return list(self.subjects)

    # ------------------------------------------------------------------
    # Tasks
    # ------------------------------------------------------------------

    def add_task(
        self,
        title: str,
        subject_code: str,
        due_date: date,
        task_type,
        priority,
        status=None,
        skip_validation: bool = False,
    ) -> AcademicTask:
        """Validate and add a new academic task.

        Args:
            title: Short description of the task.
            subject_code: Must match an existing subject's course code.
            due_date: When the task is due.
            task_type: :class:`TaskType` enum value.
            priority: :class:`Priority` enum value.
            status: Optional :class:`TaskStatus`; defaults to PENDING.
            skip_validation: When True, bypasses validator (used on JSON load).

        Returns:
            The newly created :class:`AcademicTask`.
        """
        from ai_semester_planner.models.task import TaskStatus as TS

        if status is None:
            status = TS.PENDING

        if not skip_validation:
            if self.semester is None:
                from ai_semester_planner.utils.exceptions import InvalidDateRangeError
                raise InvalidDateRangeError(
                    "A semester must be set before adding tasks."
                )
            Validator.validate_task(
                title=title,
                subject_code=subject_code,
                due_date=due_date,
                semester_start=self.semester.start_date,
                semester_end=self.semester.end_date,
                existing_codes=self._existing_codes(),
            )
        task = AcademicTask(
            title=title.strip(),
            subject_code=subject_code.strip().upper(),
            due_date=due_date,
            task_type=task_type,
            priority=priority,
            status=status,
        )
        self.tasks.append(task)
        return task

    def remove_task(self, title: str) -> None:
        """Remove the first task whose title matches *title* exactly."""
        original_count = len(self.tasks)
        self.tasks = [t for t in self.tasks if t.title != title]
        # If nothing was removed, it is a no-op (not an error).

    def get_all_tasks(self) -> list[AcademicTask]:
        """Return a copy of the tasks list."""
        return list(self.tasks)

    def update_task_status(self, title: str, new_status: TaskStatus) -> None:
        """Set the status of the task matching *title*.

        Args:
            title: Exact task title.
            new_status: Any :class:`TaskStatus` value (free-set, per D-03).
        """
        for task in self.tasks:
            if task.title == title:
                task.status = new_status
                return

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_upcoming_tasks(self, days: int = 7) -> list[AcademicTask]:
        """Return tasks due within the next *days* days, sorted by due date.

        Includes tasks due today (days_until_due == 0).
        Excludes completed tasks.
        """
        return sorted(
            [
                t
                for t in self.tasks
                if 0 <= t.days_until_due() <= days
                and t.status != TaskStatus.COMPLETED
            ],
            key=lambda t: t.due_date,
        )

    def get_overdue_tasks(self) -> list[AcademicTask]:
        """Return all overdue tasks sorted by most overdue first."""
        return sorted(
            [t for t in self.tasks if t.is_overdue()],
            key=lambda t: t.due_date,
        )

    def get_progress(self) -> dict:
        """Calculate semester progress statistics.

        Returns:
            dict with keys: total, completed, in_progress, pending, pct_complete.
        """
        total = len(self.tasks)
        completed = sum(1 for t in self.tasks if t.status == TaskStatus.COMPLETED)
        in_progress = sum(1 for t in self.tasks if t.status == TaskStatus.IN_PROGRESS)
        pending = sum(1 for t in self.tasks if t.status == TaskStatus.PENDING)
        pct = round((completed / total) * 100, 1) if total > 0 else 0.0
        return {
            "total": total,
            "completed": completed,
            "in_progress": in_progress,
            "pending": pending,
            "pct_complete": pct,
        }

    def get_tasks_by_subject(self) -> dict[str, list[AcademicTask]]:
        """Return a mapping of course_code → list of tasks for that subject."""
        result: dict[str, list[AcademicTask]] = {}
        for subject in self.subjects:
            result[subject.course_code] = [
                t
                for t in self.tasks
                if t.subject_code.upper() == subject.course_code.upper()
            ]
        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _existing_codes(self) -> list[str]:
        return [s.course_code for s in self.subjects]
