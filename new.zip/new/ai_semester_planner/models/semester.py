"""Semester dataclass."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any


@dataclass
class Semester:
    """Stores semester-level metadata."""

    name: str
    start_date: date
    end_date: date

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def contains_date(self, d: date) -> bool:
        """Return True if *d* falls within the semester window (inclusive)."""
        return self.start_date <= d <= self.end_date

    def days_remaining(self) -> int:
        """Return the number of days from today until the semester end date.

        A negative value means the semester has already ended.
        """
        return (self.end_date - date.today()).days

    def has_ended(self) -> bool:
        """Return True if the semester end date is in the past."""
        return date.today() > self.end_date

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict suitable for JSON storage."""
        return {
            "name": self.name,
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Semester":
        """Deserialise from a plain dict (as produced by :meth:`to_dict`)."""
        return cls(
            name=data["name"],
            start_date=date.fromisoformat(data["start_date"]),
            end_date=date.fromisoformat(data["end_date"]),
        )
