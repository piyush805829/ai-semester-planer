"""Subject dataclass."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class Subject:
    """Represents one academic course in a semester."""

    name: str
    course_code: str
    credits: int

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict suitable for JSON storage."""
        return {
            "name": self.name,
            "course_code": self.course_code,
            "credits": self.credits,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Subject":
        """Deserialise from a plain dict (as produced by :meth:`to_dict`)."""
        return cls(
            name=data["name"],
            course_code=data["course_code"],
            credits=int(data["credits"]),
        )
