"""Task dataclass and supporting enumerations."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from enum import Enum
from typing import Any


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------


class TaskType(str, Enum):
    """Academic task category."""

    EXAM = "Exam"
    ASSIGNMENT = "Assignment"
    PROJECT = "Project"
    OTHER = "Other"


class Priority(str, Enum):
    """Task urgency level.  Integer values enable numeric sorting."""

    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"

    @property
    def sort_key(self) -> int:
        """Lower number → higher urgency when sorted ascending."""
        _order = {Priority.HIGH: 1, Priority.MEDIUM: 2, Priority.LOW: 3}
        return _order[self]


class TaskStatus(str, Enum):
    """Current completion state of a task."""

    PENDING = "Pending"
    IN_PROGRESS = "In Progress"
    COMPLETED = "Completed"


# ---------------------------------------------------------------------------
# Task
# ---------------------------------------------------------------------------


@dataclass
class AcademicTask:
    """Represents one academic activity (exam, assignment, project, etc.)."""

    title: str
    subject_code: str
    due_date: date
    task_type: TaskType
    priority: Priority
    status: TaskStatus = field(default=TaskStatus.PENDING)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def is_overdue(self) -> bool:
        """Return True if the task is past its due date and not yet completed."""
        return self.due_date < date.today() and self.status != TaskStatus.COMPLETED

    def days_until_due(self) -> int:
        """Return days from today until the due date.

        Positive  → task is in the future.
        Zero      → task is due today.
        Negative  → task is overdue.
        """
        return (self.due_date - date.today()).days

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict suitable for JSON storage."""
        return {
            "title": self.title,
            "subject_code": self.subject_code,
            "due_date": self.due_date.isoformat(),
            "task_type": self.task_type.name,
            "priority": self.priority.name,
            "status": self.status.name,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AcademicTask":
        """Deserialise from a plain dict (as produced by :meth:`to_dict`)."""
        return cls(
            title=data["title"],
            subject_code=data["subject_code"],
            due_date=date.fromisoformat(data["due_date"]),
            task_type=TaskType[data["task_type"]],
            priority=Priority[data["priority"]],
            status=TaskStatus[data["status"]],
        )
