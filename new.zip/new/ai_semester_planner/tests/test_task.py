"""Unit tests for the AcademicTask model."""

from datetime import date, timedelta

import pytest

from ai_semester_planner.models.task import (
    AcademicTask,
    Priority,
    TaskStatus,
    TaskType,
)


def make_task(
    title: str = "Midterm Exam",
    subject_code: str = "CS201",
    days_from_today: int = 7,
    task_type: TaskType = TaskType.EXAM,
    priority: Priority = Priority.HIGH,
    status: TaskStatus = TaskStatus.PENDING,
) -> AcademicTask:
    due = date.today() + timedelta(days=days_from_today)
    return AcademicTask(
        title=title,
        subject_code=subject_code,
        due_date=due,
        task_type=task_type,
        priority=priority,
        status=status,
    )


class TestIsOverdue:
    def test_overdue_when_past_due_and_pending(self) -> None:
        task = make_task(days_from_today=-1, status=TaskStatus.PENDING)
        assert task.is_overdue() is True

    def test_overdue_when_past_due_and_in_progress(self) -> None:
        task = make_task(days_from_today=-1, status=TaskStatus.IN_PROGRESS)
        assert task.is_overdue() is True

    def test_not_overdue_when_completed_even_if_past_due(self) -> None:
        task = make_task(days_from_today=-5, status=TaskStatus.COMPLETED)
        assert task.is_overdue() is False

    def test_not_overdue_when_future_due_date(self) -> None:
        task = make_task(days_from_today=3, status=TaskStatus.PENDING)
        assert task.is_overdue() is False

    def test_not_overdue_when_due_today(self) -> None:
        task = make_task(days_from_today=0, status=TaskStatus.PENDING)
        # due_date == today is NOT overdue (strictly less-than check)
        assert task.is_overdue() is False


class TestDaysUntilDue:
    def test_positive_for_future_task(self) -> None:
        task = make_task(days_from_today=10)
        assert task.days_until_due() == 10

    def test_zero_for_task_due_today(self) -> None:
        task = make_task(days_from_today=0)
        assert task.days_until_due() == 0

    def test_negative_for_overdue_task(self) -> None:
        task = make_task(days_from_today=-3)
        assert task.days_until_due() == -3


class TestPrioritySortKey:
    def test_high_sorts_before_medium(self) -> None:
        assert Priority.HIGH.sort_key < Priority.MEDIUM.sort_key

    def test_medium_sorts_before_low(self) -> None:
        assert Priority.MEDIUM.sort_key < Priority.LOW.sort_key


class TestStatusChange:
    def test_status_can_be_set_to_any_value(self) -> None:
        task = make_task(status=TaskStatus.PENDING)
        task.status = TaskStatus.COMPLETED
        assert task.status == TaskStatus.COMPLETED

    def test_status_default_is_pending(self) -> None:
        due = date.today() + timedelta(days=5)
        task = AcademicTask(
            title="Assignment 1",
            subject_code="CS201",
            due_date=due,
            task_type=TaskType.ASSIGNMENT,
            priority=Priority.MEDIUM,
        )
        assert task.status == TaskStatus.PENDING


class TestSerialisation:
    def test_roundtrip_preserves_all_fields(self) -> None:
        original = make_task()
        restored = AcademicTask.from_dict(original.to_dict())
        assert restored.title == original.title
        assert restored.subject_code == original.subject_code
        assert restored.due_date == original.due_date
        assert restored.task_type == original.task_type
        assert restored.priority == original.priority
        assert restored.status == original.status

    def test_to_dict_keys(self) -> None:
        task = make_task()
        d = task.to_dict()
        assert set(d.keys()) == {
            "title",
            "subject_code",
            "due_date",
            "task_type",
            "priority",
            "status",
        }

    def test_enums_stored_as_name_strings(self) -> None:
        task = make_task(
            task_type=TaskType.EXAM,
            priority=Priority.HIGH,
            status=TaskStatus.IN_PROGRESS,
        )
        d = task.to_dict()
        assert d["task_type"] == "EXAM"
        assert d["priority"] == "HIGH"
        assert d["status"] == "IN_PROGRESS"
