"""Unit tests for the AIStudyPlanner service."""

from datetime import date, timedelta
from unittest.mock import MagicMock, patch

import pytest

from ai_semester_planner.models.subject import Subject
from ai_semester_planner.models.task import AcademicTask, Priority, TaskStatus, TaskType
from ai_semester_planner.services.ai_service import AIStudyPlanner, _API_KEY_ENV
from ai_semester_planner.utils.exceptions import AIServiceError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_subject(code: str = "CS201") -> Subject:
    return Subject(name="Data Structures", course_code=code, credits=3)


def make_task(days: int = 10, status: TaskStatus = TaskStatus.PENDING) -> AcademicTask:
    return AcademicTask(
        title="Assignment 1",
        subject_code="CS201",
        due_date=date.today() + timedelta(days=days),
        task_type=TaskType.ASSIGNMENT,
        priority=Priority.MEDIUM,
        status=status,
    )


# ---------------------------------------------------------------------------
# is_available()
# ---------------------------------------------------------------------------


class TestIsAvailable:
    def test_false_when_no_api_key(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            # Ensure key is absent
            import os
            os.environ.pop(_API_KEY_ENV, None)
            planner = AIStudyPlanner()
            assert planner.is_available() is False

    def test_true_when_api_key_set(self) -> None:
        with patch.dict("os.environ", {_API_KEY_ENV: "sk-test-key"}):
            planner = AIStudyPlanner()
            assert planner.is_available() is True

    def test_false_when_key_is_whitespace(self) -> None:
        with patch.dict("os.environ", {_API_KEY_ENV: "   "}):
            planner = AIStudyPlanner()
            assert planner.is_available() is False


# ---------------------------------------------------------------------------
# generate_plan() — AI unavailable / key missing
# ---------------------------------------------------------------------------


class TestGeneratePlanNoKey:
    def test_raises_ai_service_error_when_no_key(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            import os
            os.environ.pop(_API_KEY_ENV, None)
            planner = AIStudyPlanner()
            with pytest.raises(AIServiceError):
                planner.generate_plan([make_subject()], [make_task()], 4.0)


# ---------------------------------------------------------------------------
# generate_plan() — API call failures
# ---------------------------------------------------------------------------


class TestGeneratePlanAPIFailure:
    def test_raises_ai_service_error_on_api_exception(self) -> None:
        """If the openai API throws any exception, AIServiceError is raised."""
        with patch.dict("os.environ", {_API_KEY_ENV: "sk-fake"}):
            planner = AIStudyPlanner()
            with patch("openai.OpenAI") as mock_openai_cls:
                mock_client = MagicMock()
                mock_openai_cls.return_value = mock_client
                mock_client.chat.completions.create.side_effect = Exception("Network error")
                with pytest.raises(AIServiceError) as exc_info:
                    planner.generate_plan([make_subject()], [make_task()], 4.0)
                assert "Network error" in str(exc_info.value)

    def test_raises_ai_service_error_on_empty_response(self) -> None:
        """If the AI returns an empty string, AIServiceError is raised."""
        with patch.dict("os.environ", {_API_KEY_ENV: "sk-fake"}):
            planner = AIStudyPlanner()
            with patch("openai.OpenAI") as mock_openai_cls:
                mock_client = MagicMock()
                mock_openai_cls.return_value = mock_client
                mock_response = MagicMock()
                mock_response.choices[0].message.content = "   "
                mock_client.chat.completions.create.return_value = mock_response
                with pytest.raises(AIServiceError):
                    planner.generate_plan([make_subject()], [make_task()], 4.0)


# ---------------------------------------------------------------------------
# generate_plan() — successful response
# ---------------------------------------------------------------------------


class TestGeneratePlanSuccess:
    def test_returns_text_from_api(self) -> None:
        with patch.dict("os.environ", {_API_KEY_ENV: "sk-fake"}):
            planner = AIStudyPlanner()
            with patch("openai.OpenAI") as mock_openai_cls:
                mock_client = MagicMock()
                mock_openai_cls.return_value = mock_client
                mock_response = MagicMock()
                mock_response.choices[0].message.content = "Study Monday: 2h CS, 1h Math"
                mock_client.chat.completions.create.return_value = mock_response

                result = planner.generate_plan([make_subject()], [make_task()], 4.0)
                assert result == "Study Monday: 2h CS, 1h Math"

    def test_completed_tasks_excluded_from_prompt(self) -> None:
        """Completed tasks should not appear in the prompt."""
        with patch.dict("os.environ", {_API_KEY_ENV: "sk-fake"}):
            planner = AIStudyPlanner()
            completed = make_task(status=TaskStatus.COMPLETED)
            pending = make_task(days=5, status=TaskStatus.PENDING)
            prompt = planner._build_prompt([make_subject()], [completed, pending], 4.0)
            # Only pending task should be in the prompt
            assert "Assignment 1" in prompt
            # Completed tasks are filtered — both have same title, but there should
            # be exactly one entry (the pending one) — check COMPLETED label absent
            assert "Completed" not in prompt


# ---------------------------------------------------------------------------
# _build_prompt()
# ---------------------------------------------------------------------------


class TestBuildPrompt:
    def test_prompt_contains_subject_name(self) -> None:
        planner = AIStudyPlanner()
        prompt = planner._build_prompt([make_subject()], [], 4.0)
        assert "Data Structures" in prompt

    def test_prompt_contains_hours(self) -> None:
        planner = AIStudyPlanner()
        prompt = planner._build_prompt([make_subject()], [], 3.5)
        assert "3.5" in prompt

    def test_prompt_with_no_tasks_says_no_pending(self) -> None:
        planner = AIStudyPlanner()
        prompt = planner._build_prompt([make_subject()], [], 4.0)
        assert "No pending tasks" in prompt
