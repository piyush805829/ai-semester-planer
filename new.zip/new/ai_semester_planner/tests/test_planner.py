"""Unit tests for the SemesterPlanner controller."""

from datetime import date, timedelta

import pytest

from ai_semester_planner.models.planner import SemesterPlanner
from ai_semester_planner.models.task import Priority, TaskStatus, TaskType
from ai_semester_planner.utils.exceptions import (
    DuplicateCourseCodeError,
    InvalidDateRangeError,
    SubjectNotFoundError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _today() -> date:
    return date.today()


def _future(days: int) -> date:
    return _today() + timedelta(days=days)


def _past(days: int) -> date:
    return _today() - timedelta(days=days)


def make_planner_with_semester() -> SemesterPlanner:
    planner = SemesterPlanner()
    planner.set_semester("Fall 2025", _today(), _future(120))
    return planner


def add_cs_subject(planner: SemesterPlanner) -> None:
    planner.add_subject("Data Structures", "CS201", 3)


def add_math_subject(planner: SemesterPlanner) -> None:
    planner.add_subject("Calculus II", "MATH202", 4)


def add_sample_task(
    planner: SemesterPlanner,
    title: str = "Midterm Exam",
    subject_code: str = "CS201",
    days_from_today: int = 30,
    priority: Priority = Priority.HIGH,
    status: TaskStatus = TaskStatus.PENDING,
) -> None:
    planner.add_task(
        title=title,
        subject_code=subject_code,
        due_date=_future(days_from_today),
        task_type=TaskType.EXAM,
        priority=priority,
        status=status,
    )


# ---------------------------------------------------------------------------
# Subject management
# ---------------------------------------------------------------------------


class TestAddSubject:
    def test_add_subject_success(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        assert len(planner.get_all_subjects()) == 1

    def test_added_subject_fields_stored(self) -> None:
        planner = make_planner_with_semester()
        planner.add_subject("Physics", "PHY101", 2)
        subjects = planner.get_all_subjects()
        assert subjects[0].name == "Physics"
        assert subjects[0].course_code == "PHY101"
        assert subjects[0].credits == 2

    def test_course_code_normalised_to_uppercase(self) -> None:
        planner = make_planner_with_semester()
        planner.add_subject("Math", "math101", 3)
        assert planner.get_all_subjects()[0].course_code == "MATH101"

    def test_duplicate_course_code_raises(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        with pytest.raises(DuplicateCourseCodeError):
            planner.add_subject("Different Name", "CS201", 2)

    def test_duplicate_course_code_case_insensitive(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        with pytest.raises(DuplicateCourseCodeError):
            planner.add_subject("Different Name", "cs201", 2)

    def test_invalid_credits_raises(self) -> None:
        planner = make_planner_with_semester()
        from ai_semester_planner.utils.exceptions import InvalidCreditsError
        with pytest.raises(InvalidCreditsError):
            planner.add_subject("Math", "MATH1", 0)

    def test_get_subject_by_code(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        subject = planner.get_subject_by_code("cs201")
        assert subject is not None
        assert subject.name == "Data Structures"

    def test_get_subject_by_code_not_found_returns_none(self) -> None:
        planner = make_planner_with_semester()
        assert planner.get_subject_by_code("MISSING") is None


class TestRemoveSubject:
    def test_remove_subject_success(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        planner.remove_subject("CS201")
        assert len(planner.get_all_subjects()) == 0

    def test_remove_subject_not_found_raises(self) -> None:
        planner = make_planner_with_semester()
        with pytest.raises(SubjectNotFoundError):
            planner.remove_subject("MISSING")

    def test_remove_subject_cascades_to_tasks(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_math_subject(planner)
        add_sample_task(planner, title="CS Task", subject_code="CS201")
        add_sample_task(planner, title="Math Task", subject_code="MATH202")
        planner.remove_subject("CS201")
        remaining = planner.get_all_tasks()
        assert len(remaining) == 1
        assert remaining[0].title == "Math Task"


# ---------------------------------------------------------------------------
# Task management
# ---------------------------------------------------------------------------


class TestAddTask:
    def test_add_task_success(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_sample_task(planner)
        assert len(planner.get_all_tasks()) == 1

    def test_add_task_unknown_subject_raises(self) -> None:
        planner = make_planner_with_semester()
        with pytest.raises(SubjectNotFoundError):
            planner.add_task(
                "Essay",
                "UNKNOWN",
                _future(20),
                TaskType.ASSIGNMENT,
                Priority.LOW,
            )

    def test_add_task_past_due_raises(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        with pytest.raises(InvalidDateRangeError):
            planner.add_task(
                "Late Essay",
                "CS201",
                _past(1),
                TaskType.ASSIGNMENT,
                Priority.LOW,
            )

    def test_add_task_no_semester_raises(self) -> None:
        planner = SemesterPlanner()  # no semester set
        with pytest.raises(InvalidDateRangeError):
            planner.add_task(
                "Task",
                "CS201",
                _future(10),
                TaskType.ASSIGNMENT,
                Priority.LOW,
            )

    def test_remove_task(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_sample_task(planner, title="To Delete")
        planner.remove_task("To Delete")
        assert len(planner.get_all_tasks()) == 0


# ---------------------------------------------------------------------------
# Task status
# ---------------------------------------------------------------------------


class TestUpdateTaskStatus:
    def test_update_status_to_completed(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_sample_task(planner, title="Exam")
        planner.update_task_status("Exam", TaskStatus.COMPLETED)
        task = planner.get_all_tasks()[0]
        assert task.status == TaskStatus.COMPLETED

    def test_update_status_freely(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_sample_task(planner, title="Exam", status=TaskStatus.COMPLETED)
        planner.update_task_status("Exam", TaskStatus.PENDING)
        task = planner.get_all_tasks()[0]
        assert task.status == TaskStatus.PENDING


# ---------------------------------------------------------------------------
# Upcoming and overdue queries
# ---------------------------------------------------------------------------


class TestGetUpcomingTasks:
    def test_task_due_within_window_is_returned(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_sample_task(planner, title="Soon", days_from_today=5)
        upcoming = planner.get_upcoming_tasks(7)
        assert len(upcoming) == 1

    def test_task_due_outside_window_is_excluded(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_sample_task(planner, title="Far Away", days_from_today=10)
        upcoming = planner.get_upcoming_tasks(7)
        assert len(upcoming) == 0

    def test_completed_task_excluded_from_upcoming(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_sample_task(planner, title="Done", days_from_today=3, status=TaskStatus.COMPLETED)
        upcoming = planner.get_upcoming_tasks(7)
        assert len(upcoming) == 0

    def test_task_due_today_is_upcoming(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        # Set semester start to today for this specific test
        planner.semester.start_date = _today()
        add_sample_task(planner, title="Today Task", days_from_today=0)
        upcoming = planner.get_upcoming_tasks(7)
        assert len(upcoming) == 1

    def test_upcoming_sorted_by_due_date(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_sample_task(planner, title="B", days_from_today=6)
        add_sample_task(planner, title="A", days_from_today=2)
        upcoming = planner.get_upcoming_tasks(7)
        assert upcoming[0].title == "A"
        assert upcoming[1].title == "B"


class TestGetOverdueTasks:
    def test_overdue_task_returned(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        # Add overdue task bypassing validation
        planner.add_task(
            "Old Task", "CS201", _past(3),
            TaskType.EXAM, Priority.HIGH,
            skip_validation=True,
        )
        overdue = planner.get_overdue_tasks()
        assert len(overdue) == 1

    def test_completed_task_not_overdue(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        planner.add_task(
            "Done", "CS201", _past(3),
            TaskType.EXAM, Priority.HIGH,
            status=TaskStatus.COMPLETED,
            skip_validation=True,
        )
        overdue = planner.get_overdue_tasks()
        assert len(overdue) == 0


# ---------------------------------------------------------------------------
# Progress
# ---------------------------------------------------------------------------


class TestGetProgress:
    def test_no_tasks_returns_zero_pct(self) -> None:
        planner = SemesterPlanner()
        progress = planner.get_progress()
        assert progress["total"] == 0
        assert progress["pct_complete"] == 0.0

    def test_all_pending(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_sample_task(planner, "T1", days_from_today=10)
        add_sample_task(planner, "T2", days_from_today=20)
        progress = planner.get_progress()
        assert progress["pending"] == 2
        assert progress["completed"] == 0
        assert progress["pct_complete"] == 0.0

    def test_all_completed(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_sample_task(planner, "T1", status=TaskStatus.COMPLETED, days_from_today=10)
        add_sample_task(planner, "T2", status=TaskStatus.COMPLETED, days_from_today=20)
        progress = planner.get_progress()
        assert progress["pct_complete"] == 100.0

    def test_mixed_statuses(self) -> None:
        planner = make_planner_with_semester()
        add_cs_subject(planner)
        add_sample_task(planner, "T1", status=TaskStatus.COMPLETED, days_from_today=10)
        add_sample_task(planner, "T2", status=TaskStatus.PENDING, days_from_today=20)
        add_sample_task(planner, "T3", status=TaskStatus.IN_PROGRESS, days_from_today=30)
        progress = planner.get_progress()
        assert progress["total"] == 3
        assert progress["completed"] == 1
        assert progress["in_progress"] == 1
        assert progress["pending"] == 1
        assert progress["pct_complete"] == pytest.approx(33.3, abs=0.1)
