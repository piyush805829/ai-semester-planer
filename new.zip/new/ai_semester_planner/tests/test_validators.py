"""Unit tests for the Validator class."""

from datetime import date, timedelta

import pytest

from ai_semester_planner.utils.exceptions import (
    DuplicateCourseCodeError,
    EmptyFieldError,
    InvalidCreditsError,
    InvalidDateRangeError,
    InvalidStudyHoursError,
    SubjectNotFoundError,
)
from ai_semester_planner.utils.validators import Validator


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _future(days: int = 10) -> date:
    return date.today() + timedelta(days=days)


def _past(days: int = 10) -> date:
    return date.today() - timedelta(days=days)


# ---------------------------------------------------------------------------
# Semester validation
# ---------------------------------------------------------------------------


class TestValidateSemester:
    def test_valid_semester_passes(self) -> None:
        Validator.validate_semester("Fall 2025", date.today(), _future(90))

    def test_empty_name_raises(self) -> None:
        with pytest.raises(EmptyFieldError):
            Validator.validate_semester("   ", date.today(), _future(90))

    def test_name_too_long_raises(self) -> None:
        with pytest.raises(EmptyFieldError):
            Validator.validate_semester("X" * 51, date.today(), _future(90))

    def test_end_before_start_raises(self) -> None:
        with pytest.raises(InvalidDateRangeError):
            Validator.validate_semester("Sem", _future(10), date.today())

    def test_end_less_than_7_days_after_start_raises(self) -> None:
        with pytest.raises(InvalidDateRangeError):
            Validator.validate_semester("Sem", date.today(), _future(6))

    def test_end_exactly_7_days_after_start_passes(self) -> None:
        Validator.validate_semester("Sem", date.today(), _future(7))

    def test_same_start_and_end_raises(self) -> None:
        today = date.today()
        with pytest.raises(InvalidDateRangeError):
            Validator.validate_semester("Sem", today, today)


# ---------------------------------------------------------------------------
# Subject validation
# ---------------------------------------------------------------------------


class TestValidateSubject:
    def test_valid_subject_passes(self) -> None:
        Validator.validate_subject("Data Structures", "CS201", 3, [])

    def test_empty_name_raises(self) -> None:
        with pytest.raises(EmptyFieldError):
            Validator.validate_subject("", "CS201", 3, [])

    def test_whitespace_name_raises(self) -> None:
        with pytest.raises(EmptyFieldError):
            Validator.validate_subject("   ", "CS201", 3, [])

    def test_name_too_long_raises(self) -> None:
        with pytest.raises(EmptyFieldError):
            Validator.validate_subject("N" * 101, "CS201", 3, [])

    def test_empty_course_code_raises(self) -> None:
        with pytest.raises(EmptyFieldError):
            Validator.validate_subject("Math", "", 3, [])

    def test_course_code_too_long_raises(self) -> None:
        with pytest.raises(EmptyFieldError):
            Validator.validate_subject("Math", "A" * 11, 3, [])

    def test_course_code_with_spaces_raises(self) -> None:
        with pytest.raises(EmptyFieldError):
            Validator.validate_subject("Math", "CS 201", 3, [])

    def test_course_code_with_special_chars_raises(self) -> None:
        with pytest.raises(EmptyFieldError):
            Validator.validate_subject("Math", "CS@201", 3, [])

    def test_duplicate_code_raises(self) -> None:
        with pytest.raises(DuplicateCourseCodeError):
            Validator.validate_subject("Other", "CS201", 3, ["CS201"])

    def test_duplicate_code_case_insensitive(self) -> None:
        with pytest.raises(DuplicateCourseCodeError):
            Validator.validate_subject("Other", "cs201", 3, ["CS201"])

    def test_credits_zero_raises(self) -> None:
        with pytest.raises(InvalidCreditsError):
            Validator.validate_subject("Math", "MATH1", 0, [])

    def test_credits_seven_raises(self) -> None:
        with pytest.raises(InvalidCreditsError):
            Validator.validate_subject("Math", "MATH1", 7, [])

    def test_credits_negative_raises(self) -> None:
        with pytest.raises(InvalidCreditsError):
            Validator.validate_subject("Math", "MATH1", -1, [])

    def test_credits_six_passes(self) -> None:
        Validator.validate_subject("Math", "MATH1", 6, [])

    def test_credits_one_passes(self) -> None:
        Validator.validate_subject("Math", "MATH1", 1, [])


# ---------------------------------------------------------------------------
# Task validation
# ---------------------------------------------------------------------------


class TestValidateTask:
    def _sem_dates(self) -> tuple[date, date]:
        return date.today(), _future(90)

    def test_valid_task_passes(self) -> None:
        start, end = self._sem_dates()
        Validator.validate_task("Midterm", "CS201", _future(30), start, end, ["CS201"])

    def test_empty_title_raises(self) -> None:
        start, end = self._sem_dates()
        with pytest.raises(EmptyFieldError):
            Validator.validate_task("", "CS201", _future(30), start, end, ["CS201"])

    def test_title_too_long_raises(self) -> None:
        start, end = self._sem_dates()
        with pytest.raises(EmptyFieldError):
            Validator.validate_task(
                "T" * 151, "CS201", _future(30), start, end, ["CS201"]
            )

    def test_unknown_subject_raises(self) -> None:
        start, end = self._sem_dates()
        with pytest.raises(SubjectNotFoundError):
            Validator.validate_task(
                "Midterm", "UNKNOWN", _future(30), start, end, ["CS201"]
            )

    def test_past_due_date_raises(self) -> None:
        start, end = self._sem_dates()
        with pytest.raises(InvalidDateRangeError):
            Validator.validate_task(
                "Midterm", "CS201", _past(1), start, end, ["CS201"]
            )

    def test_due_today_passes(self) -> None:
        today = date.today()
        Validator.validate_task(
            "Midterm", "CS201", today, today, _future(90), ["CS201"]
        )

    def test_due_date_outside_semester_raises(self) -> None:
        start, end = self._sem_dates()
        outside = end + timedelta(days=5)
        with pytest.raises(InvalidDateRangeError):
            Validator.validate_task(
                "Midterm", "CS201", outside, start, end, ["CS201"]
            )

    def test_subject_code_case_insensitive(self) -> None:
        start, end = self._sem_dates()
        # lowercase code matches uppercase stored code
        Validator.validate_task(
            "Midterm", "cs201", _future(30), start, end, ["CS201"]
        )


# ---------------------------------------------------------------------------
# Study hours validation
# ---------------------------------------------------------------------------


class TestValidateStudyHours:
    def test_valid_hours_passes(self) -> None:
        Validator.validate_study_hours(4.0)

    def test_zero_hours_passes(self) -> None:
        Validator.validate_study_hours(0)

    def test_max_hours_passes(self) -> None:
        Validator.validate_study_hours(24)

    def test_negative_hours_raises(self) -> None:
        from ai_semester_planner.utils.exceptions import InvalidStudyHoursError

        with pytest.raises(InvalidStudyHoursError):
            Validator.validate_study_hours(-1)

    def test_over_24_hours_raises(self) -> None:
        from ai_semester_planner.utils.exceptions import InvalidStudyHoursError

        with pytest.raises(InvalidStudyHoursError):
            Validator.validate_study_hours(25)
