"""Unit tests for the Semester model."""

from datetime import date, timedelta

import pytest

from ai_semester_planner.models.semester import Semester


def make_semester(
    name: str = "Fall 2025",
    start: date | None = None,
    end: date | None = None,
) -> Semester:
    today = date.today()
    start = start or today
    end = end or (today + timedelta(days=120))
    return Semester(name=name, start_date=start, end_date=end)


class TestContainsDate:
    def test_date_on_start_is_within(self) -> None:
        s = make_semester()
        assert s.contains_date(s.start_date) is True

    def test_date_on_end_is_within(self) -> None:
        s = make_semester()
        assert s.contains_date(s.end_date) is True

    def test_date_between_start_and_end_is_within(self) -> None:
        s = make_semester()
        mid = s.start_date + timedelta(days=30)
        assert s.contains_date(mid) is True

    def test_date_before_start_is_outside(self) -> None:
        s = make_semester()
        before = s.start_date - timedelta(days=1)
        assert s.contains_date(before) is False

    def test_date_after_end_is_outside(self) -> None:
        s = make_semester()
        after = s.end_date + timedelta(days=1)
        assert s.contains_date(after) is False


class TestDaysRemaining:
    def test_future_end_date_returns_positive(self) -> None:
        today = date.today()
        s = make_semester(end=today + timedelta(days=30))
        assert s.days_remaining() == 30

    def test_past_end_date_returns_negative(self) -> None:
        today = date.today()
        s = make_semester(
            start=today - timedelta(days=60),
            end=today - timedelta(days=10),
        )
        assert s.days_remaining() == -10


class TestHasEnded:
    def test_not_ended_when_end_in_future(self) -> None:
        s = make_semester(end=date.today() + timedelta(days=1))
        assert s.has_ended() is False

    def test_ended_when_end_in_past(self) -> None:
        s = make_semester(
            start=date.today() - timedelta(days=60),
            end=date.today() - timedelta(days=1),
        )
        assert s.has_ended() is True


class TestSerialisation:
    def test_roundtrip_preserves_all_fields(self) -> None:
        original = make_semester(name="Spring 2026")
        restored = Semester.from_dict(original.to_dict())
        assert restored.name == original.name
        assert restored.start_date == original.start_date
        assert restored.end_date == original.end_date

    def test_to_dict_keys(self) -> None:
        s = make_semester()
        d = s.to_dict()
        assert set(d.keys()) == {"name", "start_date", "end_date"}

    def test_dates_stored_as_iso_strings(self) -> None:
        s = make_semester()
        d = s.to_dict()
        # Should not raise ValueError
        date.fromisoformat(d["start_date"])
        date.fromisoformat(d["end_date"])
