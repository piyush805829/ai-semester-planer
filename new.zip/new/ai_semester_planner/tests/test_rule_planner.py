"""Unit tests for the RuleBasedPlanner service."""

from datetime import date, timedelta

import pytest

from ai_semester_planner.models.subject import Subject
from ai_semester_planner.models.task import AcademicTask, Priority, TaskStatus, TaskType
from ai_semester_planner.services.rule_planner import RuleBasedPlanner, STUDY_DAYS


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _future(days: int) -> date:
    return date.today() + timedelta(days=days)


def _past(days: int) -> date:
    return date.today() - timedelta(days=days)


def make_subject(name: str = "Data Structures", code: str = "CS201", credits: int = 3) -> Subject:
    return Subject(name=name, course_code=code, credits=credits)


def make_task(
    title: str = "Task",
    code: str = "CS201",
    days: int = 10,
    priority: Priority = Priority.MEDIUM,
    status: TaskStatus = TaskStatus.PENDING,
) -> AcademicTask:
    return AcademicTask(
        title=title,
        subject_code=code,
        due_date=_future(days),
        task_type=TaskType.ASSIGNMENT,
        priority=priority,
        status=status,
    )


# ---------------------------------------------------------------------------
# generate()
# ---------------------------------------------------------------------------


class TestGenerate:
    def test_empty_subjects_returns_empty_dict(self) -> None:
        planner = RuleBasedPlanner()
        result = planner.generate([], [], 4.0)
        assert result == {}

    def test_returns_all_five_weekdays(self) -> None:
        planner = RuleBasedPlanner()
        subjects = [make_subject()]
        result = planner.generate(subjects, [], 4.0)
        assert set(result.keys()) == set(STUDY_DAYS)

    def test_each_day_has_one_block_per_subject(self) -> None:
        planner = RuleBasedPlanner()
        s1 = make_subject("DS", "CS201", 3)
        s2 = make_subject("Math", "MATH1", 2)
        result = planner.generate([s1, s2], [], 5.0)
        for day in STUDY_DAYS:
            assert len(result[day]) == 2

    def test_zero_hours_produces_zero_hour_blocks(self) -> None:
        planner = RuleBasedPlanner()
        subjects = [make_subject()]
        result = planner.generate(subjects, [], 0.0)
        for day in STUDY_DAYS:
            for block in result[day]:
                assert block["hours"] == 0.0

    def test_block_contains_required_keys(self) -> None:
        planner = RuleBasedPlanner()
        result = planner.generate([make_subject()], [], 4.0)
        block = result["Monday"][0]
        assert "subject" in block
        assert "code" in block
        assert "hours" in block


# ---------------------------------------------------------------------------
# _allocate_hours()
# ---------------------------------------------------------------------------


class TestAllocateHours:
    def test_proportional_to_credits(self) -> None:
        planner = RuleBasedPlanner()
        s1 = make_subject(code="A", credits=3)
        s2 = make_subject(code="B", credits=1)
        allocation = planner._allocate_hours([s1, s2], 4.0)
        # s1 gets 3/4 * 4 = 3.0, s2 gets 1/4 * 4 = 1.0
        assert allocation["A"] == pytest.approx(3.0, abs=0.05)
        assert allocation["B"] == pytest.approx(1.0, abs=0.05)

    def test_equal_credits_equal_hours(self) -> None:
        planner = RuleBasedPlanner()
        s1 = make_subject(code="A", credits=2)
        s2 = make_subject(code="B", credits=2)
        allocation = planner._allocate_hours([s1, s2], 4.0)
        assert allocation["A"] == allocation["B"] == pytest.approx(2.0, abs=0.05)

    def test_zero_hours_all_zeros(self) -> None:
        planner = RuleBasedPlanner()
        s1 = make_subject(code="A", credits=3)
        allocation = planner._allocate_hours([s1], 0.0)
        assert allocation["A"] == 0.0


# ---------------------------------------------------------------------------
# _sort_subjects()
# ---------------------------------------------------------------------------


class TestSortSubjects:
    def test_subject_with_overdue_task_comes_first(self) -> None:
        planner = RuleBasedPlanner()
        cs = make_subject("CS", "CS201", 3)
        math = make_subject("Math", "MATH1", 3)
        tasks = [
            make_task(code="CS201", days=-2),  # overdue
            make_task(code="MATH1", days=10),  # future
        ]
        sorted_subs = planner._sort_subjects([math, cs], tasks)
        assert sorted_subs[0].course_code == "CS201"

    def test_subject_with_no_tasks_comes_last(self) -> None:
        planner = RuleBasedPlanner()
        cs = make_subject("CS", "CS201", 3)
        math = make_subject("Math", "MATH1", 3)
        tasks = [make_task(code="CS201", days=5)]
        sorted_subs = planner._sort_subjects([math, cs], tasks)
        assert sorted_subs[-1].course_code == "MATH1"

    def test_high_priority_task_sorts_before_low(self) -> None:
        planner = RuleBasedPlanner()
        cs = make_subject("CS", "CS201", 3)
        math = make_subject("Math", "MATH1", 3)
        tasks = [
            make_task(code="CS201", days=5, priority=Priority.LOW),
            make_task(code="MATH1", days=5, priority=Priority.HIGH),
        ]
        sorted_subs = planner._sort_subjects([cs, math], tasks)
        assert sorted_subs[0].course_code == "MATH1"

    def test_completed_tasks_ignored_in_sort(self) -> None:
        planner = RuleBasedPlanner()
        cs = make_subject("CS", "CS201", 3)
        math = make_subject("Math", "MATH1", 3)
        tasks = [
            # CS has a completed overdue task — should not count
            make_task(code="CS201", days=-1, status=TaskStatus.COMPLETED),
            make_task(code="MATH1", days=5),
        ]
        sorted_subs = planner._sort_subjects([cs, math], tasks)
        # CS has no active tasks → comes last
        assert sorted_subs[-1].course_code == "CS201"


# ---------------------------------------------------------------------------
# generate_text_summary()
# ---------------------------------------------------------------------------


class TestGenerateTextSummary:
    def test_no_subjects_returns_helpful_message(self) -> None:
        planner = RuleBasedPlanner()
        result = planner.generate_text_summary([], [], 4.0)
        assert "No subjects" in result

    def test_zero_hours_returns_helpful_message(self) -> None:
        planner = RuleBasedPlanner()
        result = planner.generate_text_summary([make_subject()], [], 0.0)
        assert "0" in result

    def test_normal_output_contains_day_names(self) -> None:
        planner = RuleBasedPlanner()
        subjects = [make_subject()]
        result = planner.generate_text_summary(subjects, [], 4.0)
        assert "Monday" in result
        assert "Friday" in result
