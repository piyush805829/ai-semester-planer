"""Unit tests for the Subject model."""

from ai_semester_planner.models.subject import Subject


class TestSubjectFields:
    def test_fields_stored_correctly(self) -> None:
        s = Subject(name="Data Structures", course_code="CS201", credits=3)
        assert s.name == "Data Structures"
        assert s.course_code == "CS201"
        assert s.credits == 3


class TestSerialisation:
    def test_roundtrip_preserves_all_fields(self) -> None:
        original = Subject(name="Calculus II", course_code="MATH202", credits=4)
        restored = Subject.from_dict(original.to_dict())
        assert restored.name == original.name
        assert restored.course_code == original.course_code
        assert restored.credits == original.credits

    def test_to_dict_keys(self) -> None:
        s = Subject(name="Physics", course_code="PHY101", credits=3)
        d = s.to_dict()
        assert set(d.keys()) == {"name", "course_code", "credits"}

    def test_credits_stored_as_int_after_roundtrip(self) -> None:
        original = Subject(name="Chemistry", course_code="CHEM101", credits=2)
        d = original.to_dict()
        # credits stored as int in dict
        assert isinstance(d["credits"], int)
        # credits returned as int after from_dict
        restored = Subject.from_dict(d)
        assert isinstance(restored.credits, int)
