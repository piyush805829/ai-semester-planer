"""Unit tests for the DataStore persistence layer."""

import json
import tempfile
from datetime import date, timedelta
from pathlib import Path

import pytest

from ai_semester_planner.models.planner import SemesterPlanner
from ai_semester_planner.models.task import Priority, TaskStatus, TaskType
from ai_semester_planner.services.data_store import DataStore
from ai_semester_planner.utils.exceptions import DataStoreError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _today() -> date:
    return date.today()


def _future(days: int) -> date:
    return _today() + timedelta(days=days)


def make_populated_planner() -> SemesterPlanner:
    planner = SemesterPlanner()
    planner.set_semester("Fall 2025", _today(), _future(120))
    planner.add_subject("Data Structures", "CS201", 3)
    planner.add_subject("Calculus II", "MATH202", 4)
    planner.add_task(
        title="Midterm Exam",
        subject_code="CS201",
        due_date=_future(30),
        task_type=TaskType.EXAM,
        priority=Priority.HIGH,
        status=TaskStatus.PENDING,
    )
    planner.add_task(
        title="Problem Set 3",
        subject_code="MATH202",
        due_date=_future(15),
        task_type=TaskType.ASSIGNMENT,
        priority=Priority.MEDIUM,
        status=TaskStatus.IN_PROGRESS,
    )
    return planner


# ---------------------------------------------------------------------------
# Save and load round-trip
# ---------------------------------------------------------------------------


class TestSaveAndLoad:
    def test_roundtrip_semester(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "test.json"
            store = DataStore(file_path=path)
            original = make_populated_planner()
            store.save(original)
            restored = store.load()
            assert restored.semester is not None
            assert restored.semester.name == "Fall 2025"
            assert restored.semester.start_date == _today()
            assert restored.semester.end_date == _future(120)

    def test_roundtrip_subjects(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "test.json"
            store = DataStore(file_path=path)
            original = make_populated_planner()
            store.save(original)
            restored = store.load()
            assert len(restored.get_all_subjects()) == 2
            codes = {s.course_code for s in restored.get_all_subjects()}
            assert "CS201" in codes
            assert "MATH202" in codes

    def test_roundtrip_tasks(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "test.json"
            store = DataStore(file_path=path)
            original = make_populated_planner()
            store.save(original)
            restored = store.load()
            assert len(restored.get_all_tasks()) == 2

    def test_roundtrip_task_fields(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "test.json"
            store = DataStore(file_path=path)
            original = make_populated_planner()
            store.save(original)
            restored = store.load()
            task = next(t for t in restored.get_all_tasks() if t.title == "Midterm Exam")
            assert task.subject_code == "CS201"
            assert task.priority == Priority.HIGH
            assert task.status == TaskStatus.PENDING
            assert task.task_type == TaskType.EXAM

    def test_roundtrip_empty_planner(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "test.json"
            store = DataStore(file_path=path)
            store.save(SemesterPlanner())
            restored = store.load()
            assert restored.semester is None
            assert restored.get_all_subjects() == []
            assert restored.get_all_tasks() == []


# ---------------------------------------------------------------------------
# Missing file
# ---------------------------------------------------------------------------


class TestMissingFile:
    def test_load_returns_empty_planner_when_no_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "nonexistent.json"
            store = DataStore(file_path=path)
            planner = store.load()
            assert isinstance(planner, SemesterPlanner)
            assert planner.semester is None


# ---------------------------------------------------------------------------
# Corrupt / invalid file
# ---------------------------------------------------------------------------


class TestCorruptFile:
    def test_load_raises_data_store_error_on_corrupt_json(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "corrupt.json"
            path.write_text("THIS IS NOT JSON {{{", encoding="utf-8")
            store = DataStore(file_path=path)
            with pytest.raises(DataStoreError):
                store.load()

    def test_load_raises_data_store_error_on_invalid_task_data(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "bad_task.json"
            bad_data = {
                "semester": None,
                "subjects": [],
                "tasks": [{"title": "Broken", "bad_field": "???"}],
            }
            path.write_text(json.dumps(bad_data), encoding="utf-8")
            store = DataStore(file_path=path)
            with pytest.raises(DataStoreError):
                store.load()


# ---------------------------------------------------------------------------
# Save failure
# ---------------------------------------------------------------------------


class TestSaveFailure:
    def test_save_raises_data_store_error_on_write_failure(self) -> None:
        """Simulate an OSError during Path.open() to confirm DataStoreError is raised."""
        from unittest.mock import patch, MagicMock
        import ai_semester_planner.services.data_store as ds_module

        store = DataStore(file_path=Path("/nonexistent_dir/planner.json"))
        planner = SemesterPlanner()

        # Patch Path.mkdir so it doesn't fail on the non-existent directory,
        # then patch Path.open to raise OSError so the write path is exercised.
        with patch.object(Path, "mkdir"), \
             patch.object(Path, "open", side_effect=OSError("Permission denied")):
            with pytest.raises(DataStoreError):
                store.save(planner)
