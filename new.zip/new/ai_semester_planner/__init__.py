# ai_semester_planner package root
