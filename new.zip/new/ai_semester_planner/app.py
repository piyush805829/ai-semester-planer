"""AI Semester Planner — Streamlit entry point.

This file contains ONLY UI code.  All business logic lives in models/ and services/.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure the project root (the folder that *contains* ai_semester_planner/)
# is on sys.path so that "import ai_semester_planner.*" works when Streamlit
# is launched from inside the ai_semester_planner/ directory.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from datetime import date, timedelta
from typing import Any

import streamlit as st

from ai_semester_planner.models.planner import SemesterPlanner
from ai_semester_planner.models.task import Priority, TaskStatus, TaskType
from ai_semester_planner.services.ai_service import AIStudyPlanner
from ai_semester_planner.services.data_store import DataStore
from ai_semester_planner.services.rule_planner import RuleBasedPlanner
from ai_semester_planner.utils.exceptions import PlannerError

# ---------------------------------------------------------------------------
# Page configuration
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="AI Semester Planner",
    page_icon="📚",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Session state — load once per session
# ---------------------------------------------------------------------------

_STORE = DataStore()


def _get_planner() -> SemesterPlanner:
    if "planner" not in st.session_state:
        try:
            st.session_state["planner"] = _STORE.load()
        except PlannerError as exc:
            st.warning(f"⚠️ Could not load saved data: {exc}. Starting fresh.")
            st.session_state["planner"] = SemesterPlanner()
    return st.session_state["planner"]


def _save() -> None:
    try:
        _STORE.save(_get_planner())
    except PlannerError as exc:
        st.error(f"❌ Failed to save data: {exc}")


# ---------------------------------------------------------------------------
# Sidebar navigation
# ---------------------------------------------------------------------------

PAGES = [
    "🏠 Semester Setup",
    "📚 Subjects",
    "📝 Tasks",
    "📅 Deadlines",
    "🧠 Study Plan",
    "📊 Progress Dashboard",
]

st.sidebar.title("📚 Semester Planner")
page = st.sidebar.radio("Navigate", PAGES, label_visibility="collapsed")

# ---------------------------------------------------------------------------
# Page helpers
# ---------------------------------------------------------------------------


def _task_type_options() -> list[str]:
    return [t.value for t in TaskType]


def _priority_options() -> list[str]:
    return [p.value for p in Priority]


def _status_options() -> list[str]:
    return [s.value for s in TaskStatus]


def _priority_from_value(value: str) -> Priority:
    return next(p for p in Priority if p.value == value)


def _task_type_from_value(value: str) -> TaskType:
    return next(t for t in TaskType if t.value == value)


def _status_from_value(value: str) -> TaskStatus:
    return next(s for s in TaskStatus if s.value == value)


# ===========================================================================
# Page: Semester Setup
# ===========================================================================


def page_semester_setup() -> None:
    st.header("🏠 Semester Setup")
    planner = _get_planner()

    with st.form("semester_form"):
        name = st.text_input(
            "Semester name",
            value=planner.semester.name if planner.semester else "",
            placeholder="e.g. Fall 2025",
        )
        col1, col2 = st.columns(2)
        default_start = planner.semester.start_date if planner.semester else date.today()
        default_end = (
            planner.semester.end_date
            if planner.semester
            else date.today() + timedelta(days=120)
        )
        start_date = col1.date_input("Start date", value=default_start)
        end_date = col2.date_input("End date", value=default_end)
        submitted = st.form_submit_button("💾 Save Semester")

    if submitted:
        try:
            planner.set_semester(name, start_date, end_date)
            _save()
            st.success("✅ Semester saved successfully.")
        except PlannerError as exc:
            st.error(f"❌ {exc}")

    if planner.semester:
        st.divider()
        st.subheader("Current Semester")
        sem = planner.semester
        col1, col2, col3 = st.columns(3)
        col1.metric("Name", sem.name)
        col2.metric("Start Date", sem.start_date.strftime("%d %b %Y"))
        col3.metric("End Date", sem.end_date.strftime("%d %b %Y"))
        days_left = sem.days_remaining()
        if sem.has_ended():
            st.warning(f"⚠️ This semester ended {abs(days_left)} day(s) ago.")
        else:
            st.info(f"📆 {days_left} day(s) remaining in the semester.")


# ===========================================================================
# Page: Subjects
# ===========================================================================


def page_subjects() -> None:
    st.header("📚 Subjects")
    planner = _get_planner()

    with st.form("subject_form"):
        st.subheader("Add a New Subject")
        col1, col2, col3 = st.columns([3, 2, 1])
        name = col1.text_input("Subject name", placeholder="e.g. Data Structures")
        code = col2.text_input("Course code", placeholder="e.g. CS201")
        credits = col3.number_input("Credits", min_value=1, max_value=6, value=3, step=1)
        submitted = st.form_submit_button("➕ Add Subject")

    if submitted:
        try:
            planner.add_subject(name, code, int(credits))
            _save()
            st.success(f"✅ Subject '{name}' added.")
            st.rerun()
        except PlannerError as exc:
            st.error(f"❌ {exc}")

    st.divider()
    subjects = planner.get_all_subjects()
    if not subjects:
        st.info("No subjects added yet. Use the form above to add your first subject.")
        return

    st.subheader(f"All Subjects ({len(subjects)})")
    tasks_by_subject = planner.get_tasks_by_subject()

    for subject in subjects:
        task_count = len(tasks_by_subject.get(subject.course_code, []))
        with st.expander(f"**{subject.name}** — {subject.course_code} ({subject.credits} cr)"):
            col1, col2 = st.columns([3, 1])
            col1.write(f"**Tasks linked:** {task_count}")
            if col2.button("🗑️ Delete", key=f"del_sub_{subject.course_code}"):
                if task_count > 0:
                    st.warning(
                        f"Deleting '{subject.name}' will also delete {task_count} linked task(s)."
                    )
                    if st.button(
                        "Confirm delete", key=f"confirm_del_sub_{subject.course_code}"
                    ):
                        planner.remove_subject(subject.course_code)
                        _save()
                        st.rerun()
                else:
                    planner.remove_subject(subject.course_code)
                    _save()
                    st.rerun()


# ===========================================================================
# Page: Tasks
# ===========================================================================


def page_tasks() -> None:
    st.header("📝 Academic Tasks")
    planner = _get_planner()

    if planner.semester is None:
        st.warning("⚠️ Set up your semester first (Semester Setup page).")
        return

    if not planner.get_all_subjects():
        st.warning("⚠️ Add at least one subject before creating tasks (Subjects page).")
        return

    subjects = planner.get_all_subjects()
    subject_options = {f"{s.name} ({s.course_code})": s.course_code for s in subjects}

    with st.form("task_form"):
        st.subheader("Add a New Task")
        title = st.text_input("Task title", placeholder="e.g. Midterm Exam")
        col1, col2 = st.columns(2)
        subject_label = col1.selectbox("Subject", list(subject_options.keys()))
        due_date = col2.date_input(
            "Due date",
            value=date.today() + timedelta(days=14),
            min_value=date.today(),
        )
        col3, col4 = st.columns(2)
        task_type_val = col3.selectbox("Task type", _task_type_options())
        priority_val = col4.selectbox("Priority", _priority_options())
        submitted = st.form_submit_button("➕ Add Task")

    if submitted:
        subject_code = subject_options[subject_label]
        try:
            planner.add_task(
                title=title,
                subject_code=subject_code,
                due_date=due_date,
                task_type=_task_type_from_value(task_type_val),
                priority=_priority_from_value(priority_val),
            )
            _save()
            st.success(f"✅ Task '{title}' added.")
            st.rerun()
        except PlannerError as exc:
            st.error(f"❌ {exc}")

    st.divider()
    tasks = planner.get_all_tasks()
    if not tasks:
        st.info("No tasks added yet. Use the form above to add your first task.")
        return

    st.subheader(f"All Tasks ({len(tasks)})")

    # Build a display table with inline status editing
    for task in sorted(tasks, key=lambda t: t.due_date):
        days = task.days_until_due()
        overdue_flag = " ⚠️ OVERDUE" if task.is_overdue() else ""
        due_label = f"{task.due_date.strftime('%d %b %Y')}{overdue_flag}"

        with st.expander(
            f"**{task.title}** — {task.subject_code} | Due: {due_label} | [{task.priority.value}]"
        ):
            col1, col2, col3 = st.columns([2, 2, 1])
            col1.write(f"**Type:** {task.task_type.value}")
            col1.write(f"**Subject:** {task.subject_code}")
            col2.write(f"**Due:** {task.due_date.strftime('%d %b %Y')}")
            col2.write(f"**Days until due:** {days}")

            new_status = col3.selectbox(
                "Status",
                _status_options(),
                index=_status_options().index(task.status.value),
                key=f"status_{task.title}_{task.due_date}",
            )
            if new_status != task.status.value:
                planner.update_task_status(task.title, _status_from_value(new_status))
                _save()
                st.rerun()

            if col3.button("🗑️ Delete", key=f"del_task_{task.title}_{task.due_date}"):
                planner.remove_task(task.title)
                _save()
                st.rerun()


# ===========================================================================
# Page: Deadlines
# ===========================================================================


def page_deadlines() -> None:
    st.header("📅 Deadlines")
    planner = _get_planner()

    # ---- Upcoming ----
    st.subheader("⏰ Upcoming (next 7 days)")
    upcoming = planner.get_upcoming_tasks(7)
    if upcoming:
        rows = [
            {
                "Title": t.title,
                "Subject": t.subject_code,
                "Due Date": t.due_date.strftime("%d %b %Y"),
                "Days Left": t.days_until_due(),
                "Type": t.task_type.value,
                "Priority": t.priority.value,
                "Status": t.status.value,
            }
            for t in upcoming
        ]
        st.dataframe(rows, use_container_width=True)
    else:
        st.success("✅ No tasks due in the next 7 days.")

    st.divider()

    # ---- Overdue ----
    st.subheader("🔴 Overdue Tasks")
    overdue = planner.get_overdue_tasks()
    if overdue:
        rows = [
            {
                "Title": t.title,
                "Subject": t.subject_code,
                "Due Date": t.due_date.strftime("%d %b %Y"),
                "Days Overdue": abs(t.days_until_due()),
                "Type": t.task_type.value,
                "Priority": t.priority.value,
                "Status": t.status.value,
            }
            for t in overdue
        ]
        st.dataframe(rows, use_container_width=True)
        st.warning(f"⚠️ You have {len(overdue)} overdue task(s).")
    else:
        st.success("✅ No overdue tasks — great work!")


# ===========================================================================
# Page: Study Plan
# ===========================================================================


def page_study_plan() -> None:
    st.header("🧠 Study Plan")
    planner = _get_planner()
    subjects = planner.get_all_subjects()
    tasks = planner.get_all_tasks()

    if not subjects:
        st.info("ℹ️ Add subjects first to generate a study plan.")
        return

    st.subheader("Settings")
    hours = st.number_input(
        "Available study hours per day",
        min_value=0.0,
        max_value=24.0,
        value=4.0,
        step=0.5,
        help="How many hours can you study each day? (0–24)",
    )

    col1, col2 = st.columns(2)
    generate_ai = col1.button("🤖 Generate AI Study Plan")
    generate_rule = col2.button("📋 Generate Rule-Based Plan")

    # ---- AI Plan ----
    if generate_ai:
        try:
            from ai_semester_planner.utils.validators import Validator
            Validator.validate_study_hours(hours)
        except PlannerError as exc:
            st.error(f"❌ {exc}")
            return

        ai_planner = AIStudyPlanner()
        if not ai_planner.is_available():
            st.info(
                "ℹ️ No OpenAI API key found. Showing rule-based plan instead.\n\n"
                "Set the `OPENAI_API_KEY` environment variable to enable the AI feature."
            )
            _show_rule_based_plan(subjects, tasks, hours)
        else:
            with st.spinner("Asking AI for a study plan..."):
                try:
                    plan_text = ai_planner.generate_plan(subjects, tasks, hours)
                    st.subheader("🤖 AI Study Plan Suggestion")
                    st.markdown(plan_text)
                    st.divider()
                    st.subheader("📋 Rule-Based Schedule (for reference)")
                    _show_rule_based_plan(subjects, tasks, hours)
                except PlannerError as exc:
                    st.warning(f"⚠️ AI plan failed: {exc}\n\nShowing rule-based plan instead.")
                    _show_rule_based_plan(subjects, tasks, hours)

    # ---- Rule-based Plan ----
    if generate_rule:
        try:
            from ai_semester_planner.utils.validators import Validator
            Validator.validate_study_hours(hours)
        except PlannerError as exc:
            st.error(f"❌ {exc}")
            return
        _show_rule_based_plan(subjects, tasks, hours)


def _show_rule_based_plan(subjects, tasks, hours_per_day: float) -> None:
    rule_planner = RuleBasedPlanner()
    schedule = rule_planner.generate(subjects, tasks, hours_per_day)
    summary = rule_planner.generate_text_summary(subjects, tasks, hours_per_day)

    st.subheader("📅 Weekly Study Schedule (Mon–Fri)")
    if schedule and hours_per_day > 0:
        # Build a table: rows = subjects, columns = days
        days = list(schedule.keys())
        # Build rows indexed by subject
        subject_map: dict[str, dict[str, float]] = {}
        for day, blocks in schedule.items():
            for block in blocks:
                subj = f"{block['subject']} ({block['code']})"
                if subj not in subject_map:
                    subject_map[subj] = {}
                subject_map[subj][day] = block["hours"]

        table_rows = []
        for subj, day_hours in subject_map.items():
            row: dict[str, Any] = {"Subject": subj}
            for day in days:
                row[day] = f"{day_hours.get(day, 0.0)}h"
            table_rows.append(row)

        st.dataframe(table_rows, use_container_width=True)
    else:
        st.markdown(summary)


# ===========================================================================
# Page: Progress Dashboard
# ===========================================================================


def page_progress() -> None:
    st.header("📊 Progress Dashboard")
    planner = _get_planner()
    progress = planner.get_progress()

    # ---- Top metrics ----
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Tasks", progress["total"])
    col2.metric("✅ Completed", progress["completed"])
    col3.metric("🔄 In Progress", progress["in_progress"])
    col4.metric("📋 Pending", progress["pending"])

    if progress["total"] == 0:
        st.info("No tasks found. Add tasks to see your progress.")
        return

    st.metric("Overall Progress", f"{progress['pct_complete']}%")

    if progress["pct_complete"] == 100.0:
        st.success("🎉 Congratulations! All tasks are completed!")

    st.divider()

    # ---- Plotly pie chart ----
    try:
        import plotly.graph_objects as go

        st.subheader("Task Status Breakdown")
        labels = ["Completed", "In Progress", "Pending"]
        values = [
            progress["completed"],
            progress["in_progress"],
            progress["pending"],
        ]
        colors = ["#2ecc71", "#f39c12", "#e74c3c"]
        fig = go.Figure(
            data=[
                go.Pie(
                    labels=labels,
                    values=values,
                    hole=0.4,
                    marker=dict(colors=colors),
                )
            ]
        )
        fig.update_layout(
            showlegend=True,
            margin=dict(t=0, b=0, l=0, r=0),
            height=300,
        )
        st.plotly_chart(fig, use_container_width=True)
    except ImportError:
        st.info("Install plotly to see the chart: pip install plotly")

    st.divider()

    # ---- Per-subject breakdown ----
    st.subheader("Tasks by Subject")
    tasks_by_subject = planner.get_tasks_by_subject()
    subjects = planner.get_all_subjects()

    if not subjects:
        st.info("No subjects added yet.")
        return

    subject_rows = []
    for subject in subjects:
        subject_tasks = tasks_by_subject.get(subject.course_code, [])
        total = len(subject_tasks)
        done = sum(1 for t in subject_tasks if t.status == TaskStatus.COMPLETED)
        pending = sum(1 for t in subject_tasks if t.status == TaskStatus.PENDING)
        in_prog = sum(1 for t in subject_tasks if t.status == TaskStatus.IN_PROGRESS)
        overdue = sum(1 for t in subject_tasks if t.is_overdue())
        pct = round((done / total) * 100, 1) if total > 0 else 0.0
        subject_rows.append(
            {
                "Subject": f"{subject.name} ({subject.course_code})",
                "Credits": subject.credits,
                "Total": total,
                "Completed": done,
                "In Progress": in_prog,
                "Pending": pending,
                "Overdue": overdue,
                "Progress %": pct,
            }
        )

    st.dataframe(subject_rows, use_container_width=True)


# ===========================================================================
# Router
# ===========================================================================

if page == PAGES[0]:
    page_semester_setup()
elif page == PAGES[1]:
    page_subjects()
elif page == PAGES[2]:
    page_tasks()
elif page == PAGES[3]:
    page_deadlines()
elif page == PAGES[4]:
    page_study_plan()
elif page == PAGES[5]:
    page_progress()
