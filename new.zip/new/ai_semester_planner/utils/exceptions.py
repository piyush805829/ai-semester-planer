"""Custom exceptions for the AI Semester Planner application."""


class PlannerError(Exception):
    """Base class for all planner-related exceptions."""

    def __init__(self, message: str = "An error occurred in the planner.") -> None:
        super().__init__(message)
        self.message = message

    def __str__(self) -> str:
        return self.message


class InvalidDateRangeError(PlannerError):
    """Raised when a date range is invalid (e.g. end date before start date,
    or a task due date outside the semester window)."""

    def __init__(self, message: str = "Invalid date range.") -> None:
        super().__init__(message)


class DuplicateCourseCodeError(PlannerError):
    """Raised when a subject with the same course code already exists."""

    def __init__(self, message: str = "A subject with this course code already exists.") -> None:
        super().__init__(message)


class SubjectNotFoundError(PlannerError):
    """Raised when a task references a subject that does not exist."""

    def __init__(self, message: str = "Subject not found.") -> None:
        super().__init__(message)


class InvalidCreditsError(PlannerError):
    """Raised when credit hours are outside the valid range (1–6)."""

    def __init__(self, message: str = "Credits must be an integer between 1 and 6.") -> None:
        super().__init__(message)


class EmptyFieldError(PlannerError):
    """Raised when a required text field is blank or exceeds the maximum length."""

    def __init__(self, message: str = "Required field is empty or too long.") -> None:
        super().__init__(message)


class InvalidStudyHoursError(PlannerError):
    """Raised when available study hours are outside the valid range."""

    def __init__(self, message: str = "Study hours must be between 0 and 24.") -> None:
        super().__init__(message)


class AIServiceError(PlannerError):
    """Raised when the AI API call fails.  Caught silently by the caller,
    which then falls back to the rule-based planner."""

    def __init__(self, message: str = "AI service is unavailable.") -> None:
        super().__init__(message)


class DataStoreError(PlannerError):
    """Raised when reading from or writing to the JSON persistence file fails."""

    def __init__(self, message: str = "Data storage operation failed.") -> None:
        super().__init__(message)
