"""Input validation logic for the AI Semester Planner."""

from __future__ import annotations

import re
from datetime import date
from typing import Collection

from ai_semester_planner.utils.exceptions import (
    DuplicateCourseCodeError,
    EmptyFieldError,
    InvalidCreditsError,
    InvalidDateRangeError,
    InvalidStudyHoursError,
    SubjectNotFoundError,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_MAX_SEMESTER_NAME = 50
_MAX_SUBJECT_NAME = 100
_MAX_COURSE_CODE = 10
_MAX_TASK_TITLE = 150
_COURSE_CODE_PATTERN = re.compile(r"^[A-Za-z0-9\-]+$")


class Validator:
    """Stateless input validator.  All methods are static."""

    # ------------------------------------------------------------------
    # Semester
    # ------------------------------------------------------------------

    @staticmethod
    def validate_semester(name: str, start_date: date, end_date: date) -> None:
        """Validate semester fields.

        Raises:
            EmptyFieldError: if *name* is blank or too long.
            InvalidDateRangeError: if *end_date* is not at least 7 days after *start_date*.
        """
        stripped = name.strip()
        if not stripped:
            raise EmptyFieldError("Semester name must not be empty.")
        if len(stripped) > _MAX_SEMESTER_NAME:
            raise EmptyFieldError(
                f"Semester name must not exceed {_MAX_SEMESTER_NAME} characters."
            )
        if end_date < start_date:
            raise InvalidDateRangeError(
                "Semester end date must not be earlier than the start date."
            )
        if (end_date - start_date).days < 7:
            raise InvalidDateRangeError(
                "Semester end date must be at least 7 days after the start date."
            )

    # ------------------------------------------------------------------
    # Subject
    # ------------------------------------------------------------------

    @staticmethod
    def validate_subject(
        name: str,
        course_code: str,
        credits: int,
        existing_codes: Collection[str],
    ) -> None:
        """Validate subject fields.

        Raises:
            EmptyFieldError: if *name* or *course_code* is blank / too long / has invalid chars.
            DuplicateCourseCodeError: if *course_code* already exists (case-insensitive).
            InvalidCreditsError: if *credits* is outside 1–6.
        """
        name_stripped = name.strip()
        if not name_stripped:
            raise EmptyFieldError("Subject name must not be empty.")
        if len(name_stripped) > _MAX_SUBJECT_NAME:
            raise EmptyFieldError(
                f"Subject name must not exceed {_MAX_SUBJECT_NAME} characters."
            )

        code_stripped = course_code.strip()
        if not code_stripped:
            raise EmptyFieldError("Course code must not be empty.")
        if len(code_stripped) > _MAX_COURSE_CODE:
            raise EmptyFieldError(
                f"Course code must not exceed {_MAX_COURSE_CODE} characters."
            )
        if not _COURSE_CODE_PATTERN.match(code_stripped):
            raise EmptyFieldError(
                "Course code may only contain letters, digits, and hyphens."
            )

        existing_upper = {c.upper() for c in existing_codes}
        if code_stripped.upper() in existing_upper:
            raise DuplicateCourseCodeError(
                f"A subject with course code '{code_stripped.upper()}' already exists."
            )

        if not isinstance(credits, int) or credits < 1 or credits > 6:
            raise InvalidCreditsError(
                "Credits must be a whole number between 1 and 6 (inclusive)."
            )

    # ------------------------------------------------------------------
    # Task
    # ------------------------------------------------------------------

    @staticmethod
    def validate_task(
        title: str,
        subject_code: str,
        due_date: date,
        semester_start: date,
        semester_end: date,
        existing_codes: Collection[str],
    ) -> None:
        """Validate task fields.

        Raises:
            EmptyFieldError: if *title* is blank or too long.
            SubjectNotFoundError: if *subject_code* does not match any existing subject.
            InvalidDateRangeError: if *due_date* is in the past or outside the semester window.
        """
        title_stripped = title.strip()
        if not title_stripped:
            raise EmptyFieldError("Task title must not be empty.")
        if len(title_stripped) > _MAX_TASK_TITLE:
            raise EmptyFieldError(
                f"Task title must not exceed {_MAX_TASK_TITLE} characters."
            )

        existing_upper = {c.upper() for c in existing_codes}
        if subject_code.upper() not in existing_upper:
            raise SubjectNotFoundError(
                f"No subject with course code '{subject_code}' exists. "
                "Add the subject first."
            )

        today = date.today()
        if due_date < today:
            raise InvalidDateRangeError(
                "Task due date must be today or a future date."
            )
        if due_date < semester_start or due_date > semester_end:
            raise InvalidDateRangeError(
                "Task due date must fall within the semester dates "
                f"({semester_start.isoformat()} – {semester_end.isoformat()})."
            )

    # ------------------------------------------------------------------
    # Study hours
    # ------------------------------------------------------------------

    @staticmethod
    def validate_study_hours(hours: float) -> None:
        """Validate available study hours per day.

        Raises:
            InvalidStudyHoursError: if *hours* is negative or greater than 24.
        """
        if hours < 0 or hours > 24:
            raise InvalidStudyHoursError(
                "Available study hours must be between 0 and 24."
            )
