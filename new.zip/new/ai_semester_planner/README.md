# AI Semester Planner

A beginner-friendly Python + Streamlit application that helps students manage
their semester: subjects, academic tasks, deadlines, study schedules, and
progress tracking.  Optionally uses OpenAI GPT-3.5-turbo to generate a
personalised study-plan suggestion.

---

## Prerequisites

* Python 3.10 or higher
* pip

---

## Installation

```bash
# 1. Clone or download the project
git clone <your-repo-url>
cd ai_semester_planner

# 2. Install dependencies
pip install -r requirements.txt
```

---

## Configuration (optional AI feature)

The AI study-plan feature requires an OpenAI API key.
The application works fully without one — the rule-based planner is used instead.

**Linux / macOS**
```bash
export OPENAI_API_KEY="sk-..."
```

**Windows (Command Prompt)**
```cmd
set OPENAI_API_KEY=sk-...
```

**Windows (PowerShell)**
```powershell
$env:OPENAI_API_KEY="sk-..."
```

Alternatively, create a `.env` file in the project root:
```
OPENAI_API_KEY=sk-...
```
and install `python-dotenv`, then add `load_dotenv()` at the top of `app.py`.

---

## Running the application

```bash
streamlit run app.py
```

Open your browser at `http://localhost:8501`.

---

## Running the tests

```bash
pytest tests/ -v
```

---

## Project structure

```
ai_semester_planner/
├── app.py                    ← Streamlit entry point (UI only)
├── models/
│   ├── __init__.py
│   ├── semester.py           ← Semester dataclass
│   ├── subject.py            ← Subject dataclass
│   ├── task.py               ← Task dataclass + enums
│   └── planner.py            ← SemesterPlanner controller
├── services/
│   ├── __init__.py
│   ├── ai_service.py         ← OpenAI integration with fallback
│   ├── rule_planner.py       ← Rule-based study schedule generator
│   └── data_store.py         ← JSON persistence
├── utils/
│   ├── __init__.py
│   ├── validators.py         ← Input validation
│   └── exceptions.py         ← Custom exceptions
├── data/
│   └── .gitkeep              ← Ensures folder is tracked by git
├── tests/
│   ├── test_semester.py
│   ├── test_subject.py
│   ├── test_task.py
│   ├── test_planner.py
│   ├── test_rule_planner.py
│   ├── test_validators.py
│   ├── test_data_store.py
│   └── test_ai_service.py
├── requirements.txt
└── README.md
```

---

## Features

| Page | What it does |
|---|---|
| 🏠 Semester Setup | Create or update semester name and dates |
| 📚 Subjects | Add and remove subjects with course code and credits |
| 📝 Tasks | Add tasks, update their status, delete them |
| 📅 Deadlines | View upcoming (next 7 days) and overdue tasks |
| 🧠 Study Plan | Generate an AI or rule-based weekly study schedule |
| 📊 Progress Dashboard | Metrics, pie chart, and per-subject task breakdown |

---

## Limitations and assumptions

* Single-user, single-semester application — no authentication or multi-user support.
* Data is persisted in a plain JSON file (`data/planner_data.json`).
* The AI feature requires a paid or free-tier OpenAI API key.
* The weekly schedule covers Monday–Friday only.
* Task editing is not supported; delete and re-add instead.
* Subject editing is not supported; delete and re-add instead.
