"""AI study-plan service using OpenAI GPT-3.5-turbo."""

from __future__ import annotations

import os
from typing import Any

from ai_semester_planner.models.subject import Subject
from ai_semester_planner.models.task import AcademicTask, TaskStatus
from ai_semester_planner.utils.exceptions import AIServiceError

# Environment variable name for the API key
_API_KEY_ENV = "OPENAI_API_KEY"


class AIStudyPlanner:
    """Wraps the OpenAI Chat Completions API to generate a personalised study plan.

    If the API key is not configured or the API call fails, :class:`AIServiceError`
    is raised and the caller falls back to :class:`RuleBasedPlanner`.
    """

    def __init__(self) -> None:
        self._api_key: str = os.environ.get(_API_KEY_ENV, "").strip()

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def is_available(self) -> bool:
        """Return True if an API key is configured."""
        return bool(self._api_key)

    def generate_plan(
        self,
        subjects: list[Subject],
        tasks: list[AcademicTask],
        hours_per_day: float,
    ) -> str:
        """Call the OpenAI API and return a plain-text study plan.

        Args:
            subjects: The student's subjects for the semester.
            tasks: All tasks (only PENDING and IN_PROGRESS are included in the prompt).
            hours_per_day: Available study hours per day.

        Returns:
            Plain-text study plan suggestion from GPT-3.5-turbo.

        Raises:
            AIServiceError: If the API key is missing, the call fails, or the
                response is empty / invalid.
        """
        if not self.is_available():
            raise AIServiceError(
                "OpenAI API key not configured. "
                f"Set the {_API_KEY_ENV} environment variable."
            )

        prompt = self._build_prompt(subjects, tasks, hours_per_day)

        try:
            import openai  # imported here to avoid hard dependency at module load

            client = openai.OpenAI(api_key=self._api_key)
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are a helpful academic study advisor. "
                            "Provide clear, practical, and concise study plan suggestions. "
                            "Do not invent or modify any task deadlines or subject details."
                        ),
                    },
                    {"role": "user", "content": prompt},
                ],
                max_tokens=600,
                temperature=0.5,
            )

            text = response.choices[0].message.content
            if not text or not text.strip():
                raise AIServiceError("AI returned an empty response.")

            return text.strip()

        except AIServiceError:
            raise  # re-raise without wrapping
        except Exception as exc:
            raise AIServiceError(f"AI API call failed: {exc}") from exc

    # ------------------------------------------------------------------
    # Prompt builder
    # ------------------------------------------------------------------

    def _build_prompt(
        self,
        subjects: list[Subject],
        tasks: list[AcademicTask],
        hours_per_day: float,
    ) -> str:
        """Build the user prompt sent to GPT-3.5-turbo."""
        active_tasks = sorted(
            [t for t in tasks if t.status != TaskStatus.COMPLETED],
            key=lambda t: (t.days_until_due(), t.priority.sort_key),
        )

        subject_lines = "\n".join(
            f"  - {s.name} ({s.course_code}), {s.credits} credits"
            for s in subjects
        )

        if active_tasks:
            task_lines = "\n".join(
                f"  - [{t.priority.value}] {t.title} | Subject: {t.subject_code} "
                f"| Due: {t.due_date.isoformat()} | Type: {t.task_type.value} "
                f"| Status: {t.status.value}"
                for t in active_tasks
            )
        else:
            task_lines = "  (No pending tasks)"

        return (
            f"I am a student with {hours_per_day} study hours available per day.\n\n"
            f"My subjects this semester:\n{subject_lines}\n\n"
            f"My pending and in-progress academic tasks (sorted by urgency):\n{task_lines}\n\n"
            "Please suggest a practical Monday–Friday weekly study schedule that:\n"
            "1. Prioritises overdue and high-priority tasks first.\n"
            "2. Distributes study time proportionally by subject credit weight.\n"
            "3. Is realistic given my available daily study hours.\n"
            "4. Is formatted as a clear, readable weekly plan.\n"
            "Keep the response concise and actionable."
        )
