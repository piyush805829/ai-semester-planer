"""JSON persistence layer for the AI Semester Planner."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ai_semester_planner.models.planner import SemesterPlanner
from ai_semester_planner.models.semester import Semester
from ai_semester_planner.models.subject import Subject
from ai_semester_planner.models.task import AcademicTask
from ai_semester_planner.utils.exceptions import DataStoreError

# ---------------------------------------------------------------------------
# Default file path — data/ folder inside the project
# ---------------------------------------------------------------------------

_DEFAULT_PATH = Path(__file__).resolve().parent.parent / "data" / "planner_data.json"


class DataStore:
    """Saves and loads a :class:`SemesterPlanner` to/from a JSON file.

    Args:
        file_path: Override the default storage path (useful for testing).
    """

    def __init__(self, file_path: Path | None = None) -> None:
        self.file_path: Path = file_path or _DEFAULT_PATH

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def save(self, planner: SemesterPlanner) -> None:
        """Serialise the planner state to JSON and write it to disk.

        Raises:
            DataStoreError: If the file cannot be written.
        """
        data: dict[str, Any] = {
            "semester": planner.semester.to_dict() if planner.semester else None,
            "subjects": [s.to_dict() for s in planner.subjects],
            "tasks": [t.to_dict() for t in planner.tasks],
        }
        try:
            self.file_path.parent.mkdir(parents=True, exist_ok=True)
            with self.file_path.open("w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, ensure_ascii=False)
        except OSError as exc:
            raise DataStoreError(f"Failed to save data: {exc}") from exc

    def load(self) -> SemesterPlanner:
        """Read and deserialise the JSON file into a :class:`SemesterPlanner`.

        If the file does not exist, a fresh empty planner is returned.

        Raises:
            DataStoreError: If the file exists but is corrupted or unreadable.

        Returns:
            A :class:`SemesterPlanner` populated with the persisted state.
        """
        if not self.file_path.exists():
            return SemesterPlanner()

        try:
            with self.file_path.open("r", encoding="utf-8") as fh:
                data: dict[str, Any] = json.load(fh)
        except (OSError, json.JSONDecodeError) as exc:
            raise DataStoreError(f"Failed to load data: {exc}") from exc

        return self._deserialise(data)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _deserialise(self, data: dict[str, Any]) -> SemesterPlanner:
        """Reconstruct a SemesterPlanner from a raw dict.

        Validation is intentionally skipped on load so that:
        - Historical tasks with past due dates are still restored.
        - Semesters that have already ended are still visible.
        """
        planner = SemesterPlanner()

        # Semester
        if data.get("semester"):
            try:
                sem = Semester.from_dict(data["semester"])
                planner.set_semester(
                    sem.name,
                    sem.start_date,
                    sem.end_date,
                    skip_validation=True,
                )
            except (KeyError, ValueError) as exc:
                raise DataStoreError(f"Invalid semester data: {exc}") from exc

        # Subjects — bypass validation to allow re-loading existing data
        for subject_data in data.get("subjects", []):
            try:
                s = Subject.from_dict(subject_data)
                planner.add_subject(
                    s.name,
                    s.course_code,
                    s.credits,
                    skip_validation=True,
                )
            except (KeyError, ValueError) as exc:
                raise DataStoreError(f"Invalid subject data: {exc}") from exc

        # Tasks — bypass validation
        for task_data in data.get("tasks", []):
            try:
                t = AcademicTask.from_dict(task_data)
                planner.add_task(
                    title=t.title,
                    subject_code=t.subject_code,
                    due_date=t.due_date,
                    task_type=t.task_type,
                    priority=t.priority,
                    status=t.status,
                    skip_validation=True,
                )
            except (KeyError, ValueError) as exc:
                raise DataStoreError(f"Invalid task data: {exc}") from exc

        return planner
