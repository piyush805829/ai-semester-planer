"""Rule-based weekly study schedule generator."""

from __future__ import annotations

from datetime import date
from typing import Any

from ai_semester_planner.models.subject import Subject
from ai_semester_planner.models.task import AcademicTask, Priority, TaskStatus

# Mon–Fri study week (per D-05)
STUDY_DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]


class RuleBasedPlanner:
    """Generates a Monday–Friday study schedule without any AI API calls.

    Algorithm:
    1. Sort subjects so those with the most urgent pending tasks come first.
    2. Allocate daily study hours proportionally by credit weight.
    3. Assign the same block list to every weekday.

    If ``hours_per_day`` is 0, the schedule is returned with 0-hour blocks
    (valid state: student has set no available hours).
    """

    def generate(
        self,
        subjects: list[Subject],
        tasks: list[AcademicTask],
        hours_per_day: float,
    ) -> dict[str, list[dict[str, Any]]]:
        """Generate a Mon–Fri weekly study schedule.

        Args:
            subjects: All subjects in the planner.
            tasks: All tasks in the planner (completed tasks are ignored).
            hours_per_day: Available study hours per day (0–24).

        Returns:
            A dict mapping day name → list of study block dicts.
            Each block: ``{"subject": name, "code": course_code, "hours": float}``.
            Returns an empty dict when *subjects* is empty.
        """
        if not subjects:
            return {}

        allocations = self._allocate_hours(subjects, hours_per_day)
        sorted_subjects = self._sort_subjects(subjects, tasks)

        daily_blocks = [
            {
                "subject": s.name,
                "code": s.course_code,
                "hours": allocations[s.course_code],
            }
            for s in sorted_subjects
        ]

        return {day: list(daily_blocks) for day in STUDY_DAYS}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _allocate_hours(
        self,
        subjects: list[Subject],
        hours_per_day: float,
    ) -> dict[str, float]:
        """Return a mapping of course_code → allocated hours per day.

        Hours are proportional to each subject's credit weight.
        """
        total_credits = sum(s.credits for s in subjects)
        if total_credits == 0:
            return {s.course_code: 0.0 for s in subjects}

        return {
            s.course_code: round((s.credits / total_credits) * hours_per_day, 1)
            for s in subjects
        }

    def _sort_subjects(
        self,
        subjects: list[Subject],
        tasks: list[AcademicTask],
    ) -> list[Subject]:
        """Sort subjects so those with the most urgent pending tasks come first.

        Priority order:
        1. Overdue tasks (most overdue first).
        2. Upcoming tasks by days_until_due ascending.
        3. Subjects with no tasks go last.

        Within the same urgency bucket, higher-priority tasks (HIGH > MEDIUM > LOW)
        break ties.
        """
        active_statuses = {TaskStatus.PENDING, TaskStatus.IN_PROGRESS}

        def _urgency(subject: Subject) -> tuple[int, int, int]:
            relevant = [
                t
                for t in tasks
                if t.subject_code.upper() == subject.course_code.upper()
                and t.status in active_statuses
            ]
            if not relevant:
                return (1, 9999, 9999)  # No tasks → least urgent
            # Sort by days_until_due, then by priority sort_key
            most_urgent = min(relevant, key=lambda t: (t.days_until_due(), t.priority.sort_key))
            # Overdue tasks get bucket 0; future/today tasks get bucket 1
            bucket = 0 if most_urgent.days_until_due() < 0 else 1
            return (bucket, most_urgent.days_until_due(), most_urgent.priority.sort_key)

        return sorted(subjects, key=_urgency)

    def generate_text_summary(
        self,
        subjects: list[Subject],
        tasks: list[AcademicTask],
        hours_per_day: float,
    ) -> str:
        """Return the schedule as a readable plain-text string.

        Used as the fallback when AI is unavailable.
        """
        schedule = self.generate(subjects, tasks, hours_per_day)
        if not schedule:
            return "No subjects found. Add subjects to generate a study plan."

        if hours_per_day == 0:
            return (
                "Available study hours are set to 0. "
                "Update your daily study hours to see a schedule."
            )

        lines = ["📅 **Rule-Based Weekly Study Schedule**\n"]
        for day, blocks in schedule.items():
            lines.append(f"**{day}**")
            for block in blocks:
                lines.append(f"  • {block['subject']} ({block['code']}): {block['hours']}h")
            lines.append("")

        # Append task priority list
        active = sorted(
            [t for t in tasks if t.status != TaskStatus.COMPLETED],
            key=lambda t: (t.days_until_due(), t.priority.sort_key),
        )
        if active:
            lines.append("📋 **Task Priority Order**")
            for t in active:
                days = t.days_until_due()
                flag = "⚠️ OVERDUE" if days < 0 else f"due in {days}d"
                lines.append(f"  • [{t.priority.value}] {t.title} ({flag})")

        return "\n".join(lines)
